---
id: 4ba0cea1-7b99-4463-96ce-7dbb21156dad
type: 'card'
entityType: 'Ritual'
created: '2026-02-11T01:13:45.60695+00:00'
updated: '2026-04-05T21:43:13.783+00:00'
---

# Jökull's Proving

## Overview

[Jökull's Proving](../../world/festivals-rituals/jokull-s-proving.md) is an annual ritual hosted on the day before the New Year, where teens aged 15-18 would be chosen. These young warriors would complete a set of trials at [Frostfang](../../world/locations-landmarks/norodad/frostfang.md)  in order to become [Jökullverd](../../world/factions/jokullverd.md).

The trials are as followed: 

- Navigate the Gorges

- Haul the 3 sacred stones to the [Rimefang Alter](../../world/locations-landmarks/norodad/rimefang-alter.md)

- Complete the climb of [Gjöll's Teeth](../../world/locations-landmarks/norodad/gjoll-s-teeth.md) 

- Slay the [Hrímgarmr](../../world/entities-ecology/hrimgarmr.md) and return with it’s head.
