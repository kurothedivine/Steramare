---
id: 200a8336-db12-4776-9e4b-1aa135f4a090
type: 'card'
entityType: 'Character'
aliases: ['Reznik']
created: '2026-07-20T17:00:22.280358+00:00'
updated: '2026-08-11T00:03:21.391+00:00'
---

# Overseer Reznik

*Also known as Reznik*

**Noble House:** [House Chernoglaz](../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md)
