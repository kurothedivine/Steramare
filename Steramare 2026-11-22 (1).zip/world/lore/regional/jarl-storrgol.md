---
id: c84c53f5-38ec-456f-bed3-612bd78ebb0f
type: 'card'
entityType: 'Character'
aliases: ['Stórrgol']
created: '2026-02-10T19:03:41.82226+00:00'
updated: '2026-07-18T18:19:19.085+00:00'
---

# Jarl Stórrgol

*Also known as Stórrgol*

**Race:** [Norðdade](../../../world/races/nor-dade.md)
