---
id: 6cc09f45-c08e-4b1e-beba-8c37f6f53bc2
type: 'card'
entityType: 'Character'
created: '2026-02-11T01:51:22.71353+00:00'
updated: '2026-07-18T18:20:52.89+00:00'
---

# Jökull

**Ritual:** [Jökull's Proving](../../../world/festivals-rituals/jokull-s-proving.md)  
**Guild:** [Jökullverd](../../../world/factions/jokullverd.md)
