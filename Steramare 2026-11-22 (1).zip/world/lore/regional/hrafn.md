---
id: e1ba9e75-8747-4db7-bd3a-b9c574b274c5
type: 'card'
entityType: 'Character'
created: '2026-02-10T18:59:02.870713+00:00'
updated: '2026-07-18T18:19:37.132+00:00'
---

# Hrafn

**Race:** [Norðdade](../../../world/races/nor-dade.md)
