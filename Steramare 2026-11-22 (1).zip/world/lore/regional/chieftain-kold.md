---
id: 5f05dce9-ee1f-4bbb-9f3e-fd1e82c61806
type: 'card'
entityType: 'Character'
created: '2026-02-10T08:08:39.455438+00:00'
updated: '2026-07-18T18:19:05.041+00:00'
---

# Chieftain Kold

**Race:** [Norðdade](../../../world/races/nor-dade.md)
