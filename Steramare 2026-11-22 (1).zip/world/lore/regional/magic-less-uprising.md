---
id: c22f9ec0-06cd-436b-83fd-f79677cb1696
type: 'card'
entityType: 'Event'
created: '2026-04-05T21:32:09.903533+00:00'
updated: '2026-07-17T18:27:47.193+00:00'
---

# Magic-less Uprising

**Character:** [Aldric Breton](../../../world/lore/continental/aldric-breton.md)  
**Weapon:** [Runic Rounds](../../../world/magic/runemancy/runic-rounds.md)  
**Kingdom:** [Republic of Ruida](../../../world/kingdoms-regions/republic-of-ruida.md)
