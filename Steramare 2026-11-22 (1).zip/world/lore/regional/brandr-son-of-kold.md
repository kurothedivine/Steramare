---
id: 649350e9-361c-4ecd-8375-d512203f31f9
type: 'card'
entityType: 'Character'
aliases: ['Brandr']
created: '2026-02-10T18:49:55.008521+00:00'
updated: '2026-07-18T18:19:24.022+00:00'
---

# Brandr, Son of Kold

*Also known as Brandr*

**Race:** [Norðdade](../../../world/races/nor-dade.md)
