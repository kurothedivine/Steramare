---
id: 6742785c-6f68-4305-86ab-d7ab097d46c9
type: 'card'
entityType: 'Character'
aliases: ['Egil, Son of Jom', 'Egil']
created: '2026-02-10T19:12:01.957958+00:00'
updated: '2026-07-18T18:20:50.117+00:00'
---

# Egil

*Also known as Egil, Son of Jom, Egil*

**Race:** [Norðdade](../../../world/races/nor-dade.md)
