---
id: 185b85be-12c3-46e1-a933-469abb383409
type: 'card'
entityType: 'History'
created: '2026-07-13T20:28:01.790947+00:00'
updated: '2026-07-22T20:37:12.999+00:00'
---

# The Zaali Trials

## Overview

[The Zaali Trials](../../../world/lore/continental/the-zaali-trials.md) was a period of time shortly after [The War Against The Living](../../../world/lore/legendary/the-war-against-the-living.md)
