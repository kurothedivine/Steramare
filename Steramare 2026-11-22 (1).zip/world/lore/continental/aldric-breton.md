---
id: 16f3695a-3707-4248-8f8d-c14cb962750a
type: 'card'
entityType: 'Character'
created: '2026-04-05T18:59:08.19636+00:00'
updated: '2026-11-08T21:31:10.179+00:00'
---

# Aldric Breton

## Overview

“Some men were made with magic, others with ungodly strength. [Aldric Breton](../../../world/lore/continental/aldric-breton.md) made all men equal.”

[Aldric Breton](../../../world/lore/continental/aldric-breton.md) is the founding father of the [Runic Rounds](../../../world/magic/runemancy/runic-rounds.md), ammunition that is magically inscribed with runes. With the use of [arcpowder](../../../world/magic/runemancy/arcpowder.md) instead of [blackpowder](../../../world/weapons-armor/blackpowder.md), bullets can carry different properties.  For example, a bullet could be inscribed to expand into ice upon impact, causing wounds to be harder to tend and increasing lethality. 

Once a student at the \_\_\_\_, one of [Ruida’s](../../../world/kingdoms-regions/republic-of-ruida.md) major magic academies, he created this technology after a researching mishap which caused him to lose his magic entirely.
