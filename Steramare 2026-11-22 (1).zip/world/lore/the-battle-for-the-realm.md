---
id: ff0c4813-8ac4-4a34-ab54-9fd065116150
type: 'card'
entityType: 'Battle'
created: '2026-07-16T18:44:43.932625+00:00'
updated: '2026-08-11T00:03:07.046+00:00'
---

# The Battle for The Realm

**Kingdom:** [Norðdad](../../world/kingdoms-regions/nor-dad.md), [Ferogan Empire](../../world/kingdoms-regions/ferogan-empire.md), [Jinrami](../../world/kingdoms-regions/jinrami.md), [Republic of Ruida](../../world/kingdoms-regions/republic-of-ruida.md)
