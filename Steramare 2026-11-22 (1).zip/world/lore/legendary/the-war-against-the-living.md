---
id: d39941c5-588a-4afe-9103-6162a312b737
type: 'card'
entityType: 'War'
created: '2026-07-14T20:37:43.688299+00:00'
updated: '2026-07-14T23:28:28.563+00:00'
---

# The War Against The Living

**Kingdom:** [Republic of Ruida](../../../world/kingdoms-regions/republic-of-ruida.md), [Norðdad](../../../world/kingdoms-regions/nor-dad.md), [Ferogan Empire](../../../world/kingdoms-regions/ferogan-empire.md)  
**Faction:** [Zaali](../../../world/factions/zaali.md), [Hagiser](../../../world/factions/hagiser.md)  
**Location:** [Nochstadt](../../../world/kingdoms-regions/nochstadt.md), [Maldire](../../../world/locations-landmarks/northern-islands/maldire.md)
