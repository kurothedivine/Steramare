---
id: a1bb89fa-d7fd-4222-a688-22d05b8525f4
type: 'card'
entityType: 'Character'
aliases: ['The Ruiner', 'Lich King']
created: '2026-02-10T04:35:39.160445+00:00'
updated: '2026-11-08T20:51:45.798+00:00'
---

# The Lich King

*Also known as The Ruiner, Lich King*

**Legend:** [Origins of Steramare](../../../world/lore/legendary/origins-of-steramare.md)  
**War:** [The War Against The Living](../../../world/lore/legendary/the-war-against-the-living.md)  
**Faction:** [Zaali](../../../world/factions/zaali.md)

## Origins and Mystery

> ## Bury me shallow, I'll be back.

The true origin of the [The Lich King](../../../world/lore/legendary/the-lich-king.md) remains one of [Steramare's](../../../world/lore/legendary/origins-of-steramare.md) greatest enigmas. What is known is that he first appeared approximately 200 years before [The Shattering](../../../world/lore/legendary/the-shattering.md) , emerging from the wasteland region of [Maldire](../../../world/locations-landmarks/northern-islands/maldire.md) that would become his domain. Early accounts describe him older than what historians list, speaking languages long dead and wielding magic that had been forgotten to time.

## Philosophy and Motivation

[The Lich King](../../../world/lore/legendary/the-lich-king.md) did not see himself as evil, but more-so as inevitable. To him, death was the only truth in the universe, and life was merely a brief interruption in the last stages of the grand picture. 

To him, if the dead could stand, speak, and obey, then the line between life and death was more like an iron curtain and not a wall. Those who are strong enough can use their strength to pass through both sides of the curtain by force. [Necromancy](../../../world/magic/necromancy.md) wasn't about raising the dead for power alone; it was about revealing what he believed was the fundamental reality: that the boundary between life and death was an illusion, and that true immortality came through embracing the dirty parts of life.

His teachings, preserved in fragments by the [Zaali](../../../world/factions/zaali.md), speak of life as "the great suffering" and death to non-believers as "liberation". Those who joined him willingly saw Lich-dom as ascension, freedom from pain, hunger, aging, and loss.

## The Origin of Power

In his youth long before his ascension to lich-dom the, he found a stack of notes in a ruined shrine in the southern dunes. They belonged to [Mattai](../../../world/lore/gods-goddesses/mattai.md), [the first Balik](../../../world/lore/gods-goddesses/mattai.md) of [Jinrami](../../../world/kingdoms-regions/jinrami.md), and they described a ritual that had once pulled a woman back across the threshold.

[Mattai](../../../world/lore/gods-goddesses/mattai.md) had written the notes as a confession. They told of the rite's success, of what monstrosity came back wearing her face, and of the long grief of sealing it away. The jottings ended with a warning: that endings give shape to everything, and that to borrow from death is to rob the living.

Where [Mattai](../../../world/lore/gods-goddesses/mattai.md) wrote of horror, the Lich King heard proof of concept. A god had crossed the veil of death and returned, only lacking the nerve to finish the work.

## The War and Final Stand

For fifty years, the [The Lich King's](../../../world/lore/legendary/the-lich-king.md) armies swept across [Steramare](../../../world/lore/legendary/origins-of-steramare.md). Unlike typical conquerors, he didn't seek territory or resources—he sought converts. Every fallen enemy became a soldier. Every conquered city became a monument to his philosophy. His domain grew not through expansion but through corruption.

When [The Fated Four](../../../world/lore/legendary/the-fated-four.md) finally confronted him at \_\_\_, they used [the holy relics](../../../world/weapons-armor/the-holy-relics.md) to defeat him in a hard-fought battle.  Some accounts claim his final words before the blast were: 

> ## "You cannot kill what was never truly alive;  I am the ending you all deserve."

## The Shattering

The explosion that tore apart the continent was a purposeful last rite on an incomprehensible scale. [The Lich King](../../../world/lore/legendary/the-lich-king.md) transformed his own soul into a magical detonation of necrotic energy, fracturing not just the land but the very fabric of reality in that region. The effluvia from the scorched earth made [Maldire](../../../world/locations-landmarks/northern-islands/maldire.md) difficult to navigate for those without strong resistances to poison. This explosion created seven islands claimed with traces of  varying residual necrotic energy, with four in the Northern Sea, and three in the Southern Sea.  

The blast created what is now called [Deadwater](../../../world/entities-ecology/deadwater.md): murky, tainted water surrounding the four northern islands.  Fish pulled from its depths are often transfigured or undead. Ships that sail too long in the [Deadwater](../../../world/entities-ecology/deadwater.md) report crew members seeing visions of the dead, slowly losing their grip on reality.

## Current State

No one knows if the [The Lich King](../../../world/lore/legendary/the-lich-king.md) is truly dead. His body was obliterated in the blast, but necromancers powerful enough to achieve lichdom are notoriously difficult to permanently destroy. The [Zaali](../../../world/factions/zaali.md) believe he will return. His enemies fear they might be right.
