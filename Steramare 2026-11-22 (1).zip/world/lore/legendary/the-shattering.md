---
id: c49ca9b3-ef84-47bd-9661-f6f226b87a28
type: 'card'
entityType: 'Event'
created: '2026-02-11T04:57:57.917088+00:00'
updated: '2026-07-17T18:27:48.493+00:00'
---

# The Shattering

**Lore:** [Origins of Steramare](../../../world/lore/legendary/origins-of-steramare.md)
