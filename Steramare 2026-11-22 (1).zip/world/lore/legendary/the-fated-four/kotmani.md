---
id: b9a1949e-8566-4b79-8f41-39cf6232e4ce
type: 'card'
entityType: 'Character'
aliases: ['Ymir, daughter of Kold', 'Ymir']
created: '2026-02-10T07:39:14.795778+00:00'
updated: '2026-11-08T20:36:15.763+00:00'
---

# Kotmani

*Also known as Ymir, daughter of Kold, Ymir*

**Race:** [Norðdade](../../../../world/races/nor-dade.md)

## Overview

Wielder of the \_\_\_\_\_, she is immortalized as one of the main tenets of the [Hagiser Creed](../../../../world/factions/hagiser/hagiser-creed.md): that honor transcends blood, that justice stands above tradition, and that the worthy are chosen not by birth, but by the courage to stand in the cold and fight for what is right.

Even when the cost is everything you love.

## Fire In the Snow

[Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) was no ordinary [Norðdade](../../../../world/races/nor-dade.md) child.

Born as [Ymir](../../../../world/lore/legendary/the-fated-four/kotmani.md), she was said to be a cursed child. Not only was she a daughter as the firstborn, but she was born "under a sky with no moon". One bad omen could be called unlucky, but two would be deemed cursed indeed.

She knew that as she was, she could never become [Jökullverd](../../../../world/factions/jokullverd.md). Not only was the competition extremely high, but [Norðdade](../../../../world/races/nor-dade.md) have a very traditional society, where the men fought and the women cleaned and took care of the household. There has never been a woman who was [Jökullverd](../../../../world/factions/jokullverd.md), not because of lack of skill, but because of how the system was made. [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) was forbidden to train in combat, and was taught all mannerisms of what it meant to be a [Norðdade](../../../../world/races/nor-dade.md) woman.

The only person who believed in her was [Brandr](../../../../world/lore/regional/brandr-son-of-kold.md), the son of [Chieftain Kold](../../../../world/lore/regional/chieftain-kold.md).

Where others saw omens and curses, [Brandr](../../../../world/lore/regional/brandr-son-of-kold.md) saw fire. He found her one winter evening attempting to train with a broken spear shaft behind the longhouses, her hands bloody from the cold and splinters. Instead of mocking her or reporting her transgression, he offered her his gloves and a promise: "Meet me at dawn, beyond the frozen pines."

For three years, they met in secret. He taught her the way of the spear, the sword, the axe. She learned faster than any warrior he'd trained beside—her movements sharp as the northern wind, her determination unyielding as the glacial ice. Somewhere between the clashing of practice blades and the quiet moments catching their breath in the snow, they fell in love.

"When I become [Jökullverd](../../../../world/factions/jokullverd.md)," [Brandr](../../../../world/lore/regional/brandr-son-of-kold.md) whispered to her one night beneath the aurora's green flames, "I will change the old ways. You will stand beside me, not behind me."

But there were those who would never allow such change.

## The Shadow of Lineage

[Hrafn](../../../../world/lore/regional/hrafn.md)** was everything the **[Norðdade](../../../../world/races/nor-dade.md)** valued: noble-born, a descendant of five generations of **[Jökullverd](../../../../world/factions/jokullverd.md)**, son of **[Jarl Stórrgol](../../../../world/lore/regional/jarl-storrgol.md) ** himself. He carried his lineage like a weapon, sharp and ready to cut down any who questioned the natural order. When rumors reached his ears—whispers of **[Chieftain Kold's](../../../../world/lore/regional/chieftain-kold.md) son training a woman, and not just any woman, but the cursed firstborn daughter—his fury was ice given form.

He watched. He waited. And when the time came for [Jökull's Proving](../../../../world/festivals-rituals/jokull-s-proving.md) , he saw his opportunity.

Three were chosen that year, as always: [Brandr](../../../../world/lore/regional/brandr-son-of-kold.md) of [Chieftain Kold's](../../../../world/lore/regional/chieftain-kold.md) house, [Hrafn](../../../../world/lore/regional/hrafn.md) of [Jarl Stórrgol's](../../../../world/lore/regional/jarl-storrgol.md) bloodline, and [Egil](../../../../world/lore/regional/egil.md), a prodigy warrior who had waited years for this honor. The ritual would take them into the \_\_\_\_, where they would face the ancient ritual that separated the worthy from the dead. Only those who completed the Proving could claim the title of [Jökullverd](../../../../world/factions/jokullverd.md).

[Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) was not chosen. She could never be chosen.

But she had not spent three years training to remain behind.

## The Last Kiss

The night before the Proving, [Brandr](../../../../world/lore/regional/brandr-son-of-kold.md) came to her. "Stay," he begged, his hands cupping her face. "Let me do this. Let me win, and then I'll have the authority to change everything."

"You know I can't," she said, and kissed him one last time.

She followed them into the mountains, a shadow trailing the chosen three. The first trial was survival—navigating the razor-edged gorges where one misstep meant a fall into oblivion. The second trial was the true test of strength: hauling the sacred stones to the [Rimefang Alter](../../../../world/locations-landmarks/norodad/rimefang-alter.md).

The stones were massive, each one carved with ancient runes and heavy enough to break a normal man's back. But it was not merely a test of strength—it was a ritual. As each stone was placed upon the altar’s base, the air grew colder, the wind more violent. The three worked in unison, their breath forming clouds of frost as they lifted and carried, lifted and carried, until all three stones were in position.

When the final stone settled into place with a sound like thunder, the mountain itself seemed to awaken. The runes blazed with pale blue fire. The gateway had been opened. The ancient pact renewed.

Somewhere deep in the frozen heart of [Frostfang](../../../../world/locations-landmarks/norodad/frostfang.md), the [Hrímgarmr](../../../../world/entities-ecology/hrimgarmr.md) stirred.

But before they could face it, there was one more trial: the crossing of [Gjöll's Teeth](../../../../world/locations-landmarks/norodad/gjoll-s-teeth.md).

The Teeth were a series of ice pillars stretching across a bottomless crevasse, each one slick and treacherous. The chosen three were roped together for safety, meant to rely on each other as [Jökullverd](../../../../world/factions/jokullverd.md) must rely on their shield-brothers. It was the final passage before reaching the [Hrímgarmr's](../../../../world/entities-ecology/hrimgarmr.md) domain.

What none of them knew was that [Hrafn](../../../../world/lore/regional/hrafn.md) had spent the night before sabotaging the center pillar—chipping away its base until it would crumble under weight.

He had planned it for the cursed girl he knew would be following. He would "discover" her treachery, and when she attempted to cross, one wrong step or “accidental” stomp and the pillar would fail. An unfortunate accident. Justice for her defiance. With her dead, [Brandr's](../../../../world/lore/regional/brandr-son-of-kold.md) foolish dreams would die too, and the natural order would be preserved.

But fate is a cruel architect.

[Brandr](../../../../world/lore/regional/brandr-son-of-kold.md), ever watchful, noticed [Kotmani's](../../../../world/lore/legendary/the-fated-four/kotmani.md) distant form approaching the crossing. Saw [Hrafn's](../../../../world/lore/regional/hrafn.md) barely concealed anticipation. In a heartbeat, he understood.

"The pillar—" [Brandr](../../../../world/lore/regional/brandr-son-of-kold.md) started, lunging toward the crossing.

But [Hrafn](../../../../world/lore/regional/hrafn.md) was already moving, shoving past him with calculated force. "Chieftain's son grows paranoid in the cold!" he laughed.

[Brandr](../../../../world/lore/regional/brandr-son-of-kold.md) stumbled onto the weakened pillar. It held for one breath. Two.

Then it shattered.

[Egil](../../../../world/lore/regional/egil.md) screamed. [Hrafn](../../../../world/lore/regional/hrafn.md) grabbed the rope, his face a mask of false horror. But the weight was too much, the angle wrong—[Brandr](../../../../world/lore/regional/brandr-son-of-kold.md) plummeted into the dark, the rope burning through [Hrafn's](../../../../world/lore/regional/hrafn.md) supposedly desperate grip.

[Kotmani's](../../../../world/lore/legendary/the-fated-four/kotmani.md) scream echoed across the peaks.

## She Who Brings Cold Justice

She emerged from the shadows like a wraith of vengeance, ice in her veins and murder in her eyes. [Egil](../../../../world/lore/regional/egil.md) stood frozen in shock, but [Hrafn](../../../../world/lore/regional/hrafn.md) turned to face her with a sneer.

"The cursed child reveals herself," he spat. "You killed him. You and your defiance—he died because you couldn't accept your place."

"No," [Kotmani's](../../../../world/lore/legendary/the-fated-four/kotmani.md) voice was winter itself. "You killed him. And I will have justice."

"Justice?" [Hrafn](../../../../world/lore/regional/hrafn.md) laughed. "You have no right to justice. You have no right to even be here. I am [Jarl Stórrgol's](../../../../world/lore/regional/jarl-storrgol.md) son. I am—"

"You are a murderer who broke the sacred trial," [Egil's](../../../../world/lore/regional/egil.md) quiet voice cut through the wind. His keen eyes had seen the positioning, the timing. He had seen [Hrafn's](../../../../world/lore/regional/hrafn.md) hands. "You sabotaged the pillar. I found the chisel marks this morning but thought... I thought no one would be so dishonorable."

[Hrafn's](../../../../world/lore/regional/hrafn.md) mask cracked. His hand moved to his blade.

But [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) was faster.

The fight was brutal and brief. For all his noble training, [Hrafn](../../../../world/lore/regional/hrafn.md) had never faced someone who fought like she had something to die for. She disarmed him, drove him to his knees at the edge of the crevasse where [Brandr](../../../../world/lore/regional/brandr-son-of-kold.md) had fallen.

"The Proving is sacred law," she said, her blade at his throat. "Within its bounds, justice stands above all rank, all blood, all tradition. You broke the sacred trial. You murdered your shield-brother. The punishment is death."

"You're a woman," [Hrafn](../../../../world/lore/regional/hrafn.md) gasped. "A cursed—"

She drove the blade home.

In the silence that followed, [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) looked at [Egil](../../../../world/lore/regional/egil.md) the Silent. "I will complete the Proving," she said. "I will take his place in the three. And if you stand against me, you will have to kill me here."

[Egil](../../../../world/lore/regional/egil.md) studied her for a long moment. Then he nodded once. "[Brandr](../../../../world/lore/regional/brandr-son-of-kold.md) would have changed the old ways. Perhaps this is how it begins."

"Then we have one trial left," [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) said, her eyes turning toward the deeper peaks. "The [Hrímgarmr](../../../../world/entities-ecology/hrimgarmr.md) awaits."

## The End of the Beginning

The [Hrímgarmr](../../../../world/entities-ecology/hrimgarmr.md) was ancient beyond reckoning, a magical beast of living ice and primordial fury. It stood twice the height of a man at the shoulder, its body covered in crystalline fur that gleamed like fractured starlight. Its eyes burned with cold blue fire, and its breath came in clouds of frost that could freeze flesh in seconds. For generations, it had tested those who would be [Jökullverd](../../../../world/factions/jokullverd.md), and for generations, it had tasted their blood.

The creature had been summoned by the placement of the sacred stones, drawn forth to fulfill its eternal purpose. When [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) and [Egil](../../../../world/lore/regional/egil.md) entered its domain—a vast ice cavern beneath the peak where the bones of failed warriors lay frozen in the walls—it was waiting.

The battle was savage. [Egil](../../../../world/lore/regional/egil.md) fought with the precision of experience, his strikes measured and defensive. But [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) fought with the fury of grief unleashed, every movement a prayer to [Brandr's](../../../../world/lore/regional/brandr-son-of-kold.md) memory, every strike an answer to the unfairness of the world.

The [Hrímgarmr](../../../../world/entities-ecology/hrimgarmr.md) was fast despite its size, its claws carving gouges in the ice floor as it lunged and snapped. It caught [Egil](../../../../world/lore/regional/egil.md) with a glancing blow that sent him crashing into the cavern wall, leaving [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) to face it alone.

She thought of [Brandr's](../../../../world/lore/regional/brandr-son-of-kold.md) hands guiding hers through a spear form. She thought of his promise beneath the aurora. She thought of his fall.

And she stopped thinking entirely.

Her blade found the gaps in its crystalline armor, striking again and again until the [Hrímgarmr's](../../../../world/entities-ecology/hrimgarmr.md) movements slowed, until its burning eyes began to dim. With a final, desperate lunge, she drove her weapon deep into the beast's throat. It collapsed with a sound like an avalanche, its body already beginning to sublimate back into the eternal ice from which it came.

But the head remained solid. Proof of victory. Proof of worthiness.

[Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) severed it with three heavy strikes, her arms screaming with exhaustion. [Egil](../../../../world/lore/regional/egil.md), bloodied but alive, limped to her side and together they began the long journey back.

When they returned to the [Norðdade](../../../../world/races/nor-dade.md) settlements, [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) walked with the [Hrímgarmr's](../../../../world/entities-ecology/hrimgarmr.md) frozen head held high in one hand and [Brandr's](../../../../world/lore/regional/brandr-son-of-kold.md) token clutched in the other, both stained with blood—one from a monster, one from a man who should never have died.

[Jarl Stórrgol](../../../../world/lore/regional/jarl-storrgol.md) demanded her head. But she had acted within the Proving, where sacred law superseded even a Jarl's will. The elders argued for days, but in the end, they could not deny it: she had completed the trials. She had exposed treachery. She had enacted justice according to the old laws. She had slain the [Hrímgarmr](../../../../world/entities-ecology/hrimgarmr.md).

They named her [Jökullverd](../../../../world/factions/jokullverd.md), the first woman to ever bear the title.

They also named her [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md)—"glorious moon"—and though some called it an honor, she knew it for what it was: a reminder that she was different. Cursed. Other.

But she had kept her promise to [Brandr](../../../../world/lore/regional/brandr-son-of-kold.md). She had changed [Norðdad](../../../../world/kingdoms-regions/nor-dad.md), even if it cost her everything.

## The Divine Seven

## Appearance

[Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) has long braided white hair, with topaz colored eyes. Bearing pale skin, her scars from battle and [conflicts](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) are easily visible, with one notable one fashioned like a stream of tears coming from her eyes. She has a tall, yet slender build, standing around 6'1.

## Personality

- [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) sees the world in stark terms of right and wrong, honor and dishonor. She calls her vengeance "justice" not as a rationalization, but because she genuinely believes in the rightness of her actions within the sacred laws. This moral certainty gives her strength but also makes her inflexible—she holds herself and others to an uncompromising standard. Those who break faith, betray trust, or act dishonorably will find no mercy in her.

- Beneath her cold exterior lies profound grief. [Brandr's](../../../../world/lore/regional/brandr-son-of-kold.md) death weighs on her constantly—he died because of her ambition, her refusal to stay hidden. Though she tells herself (and others) that she enacted justice, she carries guilt like a second shadow. This trauma manifests as emotional distance; she keeps people at arm's length, unable to bear the thought of losing someone else she cares for.

- Despite achieving what should have been her greatest triumph, [Kotmani](../../../../world/lore/legendary/the-fated-four/kotmani.md) remains an outsider. She is "cursed," "other," the woman who broke tradition. Even her name—given as both honor and reminder—marks her as different. This isolation has made her self-reliant to a fault. She trusts few, relies on herself, and has learned that standing alone is often the price of standing at all.
