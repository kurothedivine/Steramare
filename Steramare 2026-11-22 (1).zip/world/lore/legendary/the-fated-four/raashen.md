---
id: b5da81fe-e1b1-427a-8690-e0bcd3017ffd
type: 'card'
entityType: 'Character'
created: '2026-07-22T20:10:39.0512+00:00'
updated: '2026-07-22T20:35:45.02+00:00'
---

# Raashen
