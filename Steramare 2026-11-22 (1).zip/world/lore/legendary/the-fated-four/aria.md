---
id: 81248d3f-ca60-443f-a53c-614fb5bd45c6
type: 'card'
entityType: 'Character'
aliases: ['Aria of the Emerald Circle']
created: '2026-07-22T20:34:55.879378+00:00'
updated: '2026-07-22T20:35:45.02+00:00'
---

# Aria

*Also known as Aria of the Emerald Circle*
