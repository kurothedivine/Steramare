---
id: 594f3da7-5638-4e79-918b-2c3961d802db
type: 'card'
entityType: 'Legend'
aliases: ['Fated Five', 'Champions of the Hagiser']
created: '2026-02-10T05:15:01.491469+00:00'
updated: '2026-11-07T19:25:31.39+00:00'
---

# The Fated Four

*Also known as Fated Five, Champions of the Hagiser*

**Lore:** [Origins of Steramare](../../../world/lore/legendary/origins-of-steramare.md)

## Overview

The [The Fated Four](../../../world/lore/legendary/the-fated-four.md) was the brainchild \_\_\_\_, a legendary mage and artificer who created   artifacts called the [The Holy Relics](../../../world/weapons-armor/the-holy-relics.md) with the sole purpose and intent to destroy the [Lich King](../../../world/lore/legendary/the-lich-king.md) and the [Zaali](../../../world/factions/zaali.md). Each of these indestructible artifacts took several years of his life to construct, being infused with his magic. 

Rumor has it that the magical effects and boons it grants the wielders are amplified because of the pacts he made with primordial forces. Each artifact could only be wielded by those who were deemed worthy of the Tenant infused into them, so they were split across some of the strongest warriors across the continent:

These tenants later became the cornerstones of the [Hagiser](../../../world/factions/hagiser.md), and crucial to the [Hagiser Creed](../../../world/factions/hagiser/hagiser-creed.md). 

## The Holy Artifacts

[Skysplitter](../../../world/weapons-armor/the-holy-relics/skysplitter.md), wielded by [Raashen](../../../world/lore/legendary/the-fated-four/raashen.md).

, wielded by [Kotmani](../../../world/lore/legendary/the-fated-four/kotmani.md).

[Angel Tears](../../../world/angel-tears.md) ,  wielded by [Aria of the Emerald Circle](../../../world/lore/legendary/the-fated-four/aria.md) .
