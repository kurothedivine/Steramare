---
id: df09cbca-cd50-4961-8126-f4357059a91b
type: 'card'
entityType: 'Lore'
aliases: ['Steramare']
created: '2026-02-10T04:45:40.59905+00:00'
updated: '2026-07-14T22:49:53.118+00:00'
---

# Origins of Steramare

*Also known as Steramare*
