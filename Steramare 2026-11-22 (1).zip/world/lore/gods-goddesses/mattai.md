---
id: 963d95d7-42b4-412b-94ca-4a87edad0e4d
type: 'card'
entityType: 'Character'
aliases: ['The First Balik']
created: '2026-07-22T20:15:05.266284+00:00'
updated: '2026-11-08T01:14:38.302+00:00'
---

# Mattai

*Also known as The First Balik*

## Notes

- Sun demigod who loved the [katari](../../../world/races/katari.md), had a [katari](../../../world/races/katari.md) lover named [Seteta](../../../world/kingdoms-regions/jinrami/seteta.md) (secret lover?) - I'm thinking enemies to lovers vibe, similarly to Moses and Tzipporah in the DreamWorks film Prince of Egypt movie (some sort of misunderstanding gives setata a bad impression of mattai)

- [Tomb of Seteta](../../../world/tomb-of-seteta.md)

- tried to revive his dead wife but ended up realizing the error of his ways, maybe he went to another deity for help? (thinking some sort of mistress of death)

- the revival caused her to become an undead monstrosity, he was able to seal her but could not destroy her because of his love for [Seteta](../../../world/kingdoms-regions/jinrami/seteta.md)

- became some sort of inspirational figure for [the Lich King](../../../world/lore/legendary/the-lich-king.md) in later years, but [the lich king](../../../world/lore/legendary/the-lich-king.md) twisted/misinterpeted his notes about the ritual, mattai served as an origin of influence for [the Lich King](../../../world/lore/legendary/the-lich-king.md) and the [Zaali's](../../../world/factions/zaali.md) philosophy

- had the [Crown of Influence](../../../world/crown-of-influence.md), maybe the [Zaali](../../../world/factions/zaali.md) are hunting it to see if they can mass control an army or de-law [necromancy](../../../world/magic/necromancy.md)?

- the [crown of influence](../../../world/crown-of-influence.md) was a tool he created to unite the [katari](../../../world/races/katari.md) and [humans](../../../world/races/human.md) so they can coexist in [jinrami](../../../world/kingdoms-regions/jinrami.md) - explain in the future HOW/WHY the crown was buried. Maybe Mattai realized how future [balik's](../../../world/kingdoms-regions/jinrami/balik.md) could exploit this

- unofficial first [balik](../../../world/kingdoms-regions/jinrami/balik.md) of [jinrami](../../../world/kingdoms-regions/jinrami.md) 

## The Caravan's Tales

Before [Jinrami](../../../world/kingdoms-regions/jinrami.md) had walls, it had a fire, and the fire had a name. The caravan elders say Mattai ventured into the endless deserts leaving his footprints burning, so that lost travelers could follow him to water. He didn't ask for temples, tithes, and sacrifices, but for others to not be left alone in the scorching wasteland. The first settlements gathered where his footprints stopped, and the people built close to the warmth he left behind.

## A Quarrel at the Oasis

Their first meeting went badly, and neither of them ever pretended otherwise.

[Seteta](../../../world/kingdoms-regions/jinrami/seteta.md) was a [Katari](../../../world/races/katari.md) tracker, sharp of tongue and sharper of claw, searching the dunes for her kin taken by poachers. At sunrise she came upon a stranger walking out of a poachers' camp with his arms full of bundled pelts and a purse conspicuously lighter than it had been. He did not stop to explain himself. He simply kept walking, glowing faintly, like a man who had never been told that was rude.

She took him for a buyer. She followed him for three days, hurling insults at his back in a voice that could curdle milk, and he bore all of it with the helpless patience of someone who could not figure out how to begin.

On the fourth dawn she watched him dig a grave in the sand. He laid each pelt down with care, spoke the old words over them, and set the sun itself above the mound to keep it warm. [Seteta](../../../world/kingdoms-regions/jinrami/seteta.md) stood there for a long while. Then she walked out of the shadows and said, "You could have just told me."

"You were very loud," said Mattai.

It took the better part of a decade for them to forgive one another, and a good deal longer to say what both already knew.

## What the Chronicle Omits

The official histories of [Jinrami](../../../world/kingdoms-regions/jinrami.md) credit the founding to the Gold Sovereign and the early royal line. Mattai appears only in the margins, as a patron of dawn and a symbol on coins. In practice he ruled before any crown existed. He settled disputes, drew borders with a burning staff, and named the first houses. Scholars who use the word [balik](../../../world/kingdoms-regions/jinrami/balik.md) for the earliest rulers rarely admit that the first one was never recorded as holding the title.

His love for [Seteta](../../../world/kingdoms-regions/jinrami/seteta.md), and for the [Katari](../../../world/races/katari.md) she represented, is absent from every surviving record. Historians who have noticed the gap tend to assume it was never there. It was erased by time, then by convenience, and finally by a society that found it easier to keep the [Katari](../../../world/races/katari.md) as second class citizens when no god had ever spoken for them.

## The Crown That Was Meant to Bind Gently

Mattai made the [Crown of Influence](../../../world/crown-of-influence.md) for one purpose. He wanted [Katari](../../../world/races/katari.md) and [humans](../../../world/races/human.md) to share [Jinrami](../../../world/kingdoms-regions/jinrami.md) as equals, and he knew that wanting it would not be enough. The Crown let its wearer's will settle softly on those nearby. It calmed fear, eased old grudges and made strangers willing to sit at the same table.

He wore it rarely. He did not like how easily people agreed with him once it was on.

> *From a fragment attributed to *[Seteta](../../../world/kingdoms-regions/jinrami/seteta.md)*:* *You gave them a crown to make them kind. I would rather you gave them a reason. But I have watched you carry it, and I know you do not want to be obeyed. That is the only thing that makes me trust it.*

## The Price of Asking

[Seteta](../../../world/kingdoms-regions/jinrami/seteta.md) died. The accounts disagree on how, and Mattai never spoke of it.

What the records do agree on is that the sun demigod, who had spent his life warming others, found he could not warm the one he needed most. He went looking for someone who could. Past the last oasis, in a hollow where the light would not follow him, he found a pale and patient figure whom the old texts call the **Mistress of Death**. Her name here is a placeholder: *Nehira*.

She agreed. Gods rarely refuse a bargain when the terms are sorrow.

What came back through the threshold was not [Seteta](../../../world/kingdoms-regions/jinrami/seteta.md). It had her height and her voice, but it moved wrong and spoke without listening. It hungered, and it did not know why. Mattai watched it tear a hole through the wall of the ritual chamber and understood, all at once, what he had done.

He sealed it. He could not destroy it. Every time he raised his hand, he saw the quarrel at the well, the grave in the sand and the woman who had once told him he should have just explained himself. So he left her sealed instead, and carried that choice for the rest of his life.

## The Long Dimming

After the rite Mattai grew dim. The dawn over [Jinrami](../../../world/kingdoms-regions/jinrami.md) came late and pale. He stopped walking the sand, stopped answering prayers, and stopped recording his own work. The people noticed that their sun was tired, though few understood why.

He built a tomb beneath the dunes and closed it around what remained of [Seteta](../../../world/kingdoms-regions/jinrami/seteta.md). Then he did something he had never done with the [Crown of Influence](../../../world/crown-of-influence.md). He set it down. He laid it in the tomb beside her and walled up the door.

The reason he gave was grief. The reason he left behind was different. Somewhere in those years Mattai understood what a Crown like his could become in the hands of a ruler who did not share his doubts. The full account of how he reached that conclusion, and what he saw, is held back for another time.

## The Seed of a Terrible Idea

Centuries later, a scholar who would become [the Lich King](../../../world/lore/legendary/the-lich-king.md) found a ruined shrine and, inside it, a stack of notes on the ritual. He read the sorrow and the warning as inconvenient commentary. He read the method as a discovery.

[The Lich King](../../../world/lore/legendary/the-lich-king.md) took the god's grief for a proof of concept. He bent Mattai's words about memory and loss into a creed that promised mastery over both, and he treated the notes as a blueprint rather than a confession. The [Zaali](../../../world/factions/zaali.md) inherited the twisted gospel. The best of them do not know its source. The worst know exactly where it came from, and regard the Kindled Father as an unwilling founder of their faith.

## What Was Done With the Crown

[Jinrami](../../../world/kingdoms-regions/jinrami.md) has a rumor it prefers not to repeat. It says that the Crown, or some copy of its power, was used against the people it was meant to protect. [Katari](../../../world/races/katari.md) villages were quieted and their fear dulled while hunters moved through. It was fur poaching on a scale that nobody could have carried out against a people who were frightened.

[Katari](../../../world/races/katari.md) pelts fetch a very high price, and that is why the rumor died. As the trade grew rich, [Jinrami](../../../world/kingdoms-regions/jinrami.md) houses found it easier to forget how it began. Ledgers were rewritten, hunting grounds were renamed, and the story folded into the long habit of looking away.

The [Zaali](../../../world/factions/zaali.md) want the Crown for reasons that differ by faction:

- **The Orthodox** believe the Crown can bind a vast army of the dead to a single will.

- **The Philosophers** think it might rewrite the laws that forbid [necromancy](../../../world/magic/necromancy.md), by persuading a whole population to stop objecting.

- **The Opportunists** simply want to sell it.

Whoever holds it does not have to be wicked to do harm. They only have to be certain.

## The [Tomb of Seteta](../../../world/tomb-of-seteta.md) (Dungeon Notes)

The dungeon is [Seteta's](../../../world/kingdoms-regions/jinrami/seteta.md) tomb. Mattai sealed it with his own hands, and the sun still rises on it a little reluctantly. Some hooks for building it:

- **The Kindled Gallery:** murals showing Mattai and [Seteta](../../../world/kingdoms-regions/jinrami/seteta.md) together, her face scratched out in some places and lovingly restored in others. Players who read the order of the damage will learn who visited and when.

- **The Well of First Words:** an antechamber echoing their first quarrel. A party that speaks plainly is rewarded, and one that stays silent triggers a cold, cutting reply from the walls.

- **The Hollow **[Seteta](../../../world/kingdoms-regions/jinrami/seteta.md)**:** the undead guardian, still sealed and still hungry. She should be dangerous and difficult to hurt without hesitation. A [Katari](../../../world/races/katari.md) party member may recognize the way she moves.

- **The Ledger Wall:** a chamber carved with [Katari](../../../world/races/katari.md) village names and pelt counts. It is evidence [Jinrami](../../../world/kingdoms-regions/jinrami.md) would pay well to keep buried.

- **The **[Zaali](../../../world/factions/zaali.md)** Dig Teams:** already inside, working in shifts. Some can be reasoned with, and some are listening to a different voice entirely.

- **The Crown's Chamber:** the Crown rests in a room that rewards restraint. Taking it by force should cost more than leaving it.

---

*"I asked the sun to give her back. The sun, being wiser than I, said no."* — Attributed to Mattai, from a fragment in the tomb
