---
id: bef31fcd-53ec-4a27-9f10-a277217ac74c
type: 'card'
entityType: 'Character'
aliases: ['Goddess of Nature']
created: '2026-07-13T19:44:24.208547+00:00'
updated: '2026-07-22T20:37:12.999+00:00'
---

# Aether

*Also known as Goddess of Nature*

**Kingdom:** [Norðdad](../../../world/kingdoms-regions/nor-dad.md)  
**Location:** [Aether's End](../../../world/kingdoms-regions/aether-s-end.md)  
**Lore:** [Origins of Steramare](../../../world/lore/legendary/origins-of-steramare.md)
