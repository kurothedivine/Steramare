---
id: d1557fc6-01ab-467b-9c4f-ab6455113981
type: 'card'
entityType: 'Artifact'
created: '2026-02-10T09:59:32.080581+00:00'
updated: '2026-11-22T18:25:19.174+00:00'
---

# The Holy Relics

## The Seven Artifacts

[Skysplitter](../../world/weapons-armor/the-holy-relics/skysplitter.md), the Dawnforged Spear of Justice, wielded by [Kotmani](../../world/lore/legendary/the-fated-four/kotmani.md).

,The Molten Gauntlets of Courage , wielded by \_\_\_\_.

, The Expanding Shield of Sacrifice,  wielded by \_\_\_\_,.

, The Everlasting Pendant of Hope,  wielded by \_\_\_\_,.

, The Chained Blades of Fervor,  wielded by \_\_\_\_,.
