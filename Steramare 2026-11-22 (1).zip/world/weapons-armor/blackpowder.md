---
id: 4437608c-c54e-45d8-ad34-450fb11cf996
type: 'card'
entityType: 'Weapon'
created: '2026-04-06T00:44:32.655177+00:00'
updated: '2026-07-13T19:27:55.191+00:00'
---

# Blackpowder
