---
id: 8d415a78-0b90-4c57-b9ee-6a6cd3713ead
type: 'card'
entityType: 'Weapon'
aliases: ['Skysplitter']
created: '2026-02-10T05:14:01.852732+00:00'
updated: '2026-07-22T20:18:47+00:00'
---

# Skysplitter

*Also known as Skysplitter*

**Artifact:** [The Fated Four](../../../world/lore/legendary/the-fated-four.md), [The Holy Relics](../../../world/weapons-armor/the-holy-relics.md)
