---
id: 3332a7ca-6cc7-4a6d-84be-e8e2d4fa205d
type: 'card'
entityType: 'Location'
aliases: ['Scarlet Forest']
created: '2026-07-13T19:34:58.990929+00:00'
updated: '2026-07-16T17:13:02.287+00:00'
---

# The Scarlet Forest

*Also known as Scarlet Forest*

**Location:** [Aether's End](../../../world/kingdoms-regions/aether-s-end.md)
