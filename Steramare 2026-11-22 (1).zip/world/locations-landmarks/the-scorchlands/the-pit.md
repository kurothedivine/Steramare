---
id: a3be8c61-7a32-4a61-aad7-1bfaa36d96d6
type: 'card'
entityType: 'Location'
created: '2026-07-16T16:21:43.789057+00:00'
updated: '2026-07-16T17:12:33.748+00:00'
---

# The Pit
