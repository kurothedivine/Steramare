---
id: f29e42e6-cd3d-4f1f-9181-720f959b353a
type: 'card'
entityType: 'Location'
created: '2026-02-23T22:58:43.141606+00:00'
updated: '2026-07-16T17:12:33.748+00:00'
---

# Ember Run
