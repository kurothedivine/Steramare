---
id: 803cf150-3946-418d-8169-2b4fc7893448
type: 'card'
entityType: 'Location'
created: '2026-04-05T14:11:15.113985+00:00'
updated: '2026-04-07T01:20:49.964+00:00'
---

# Maldire

[Maldire](../../../world/locations-landmarks/northern-islands/maldire.md) is the most tainted island, being the primary landmass that [the Lich King](../../../world/lore/legendary/the-lich-king.md) resided before [The Shattering](../../../world/lore/legendary/the-shattering.md). This island reeks of necrotic energy, so much so that many people without some sort of necrotic resistance end up dying… or worse. 

[Maldire](../../../world/locations-landmarks/northern-islands/maldire.md) is unofficially home of the [Zaali’s](../../../world/factions/zaali.md) most faithful, since many of them are not targeted by the undead monstrosities that have been created there.
