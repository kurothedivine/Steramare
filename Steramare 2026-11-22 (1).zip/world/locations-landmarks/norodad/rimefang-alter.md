---
id: fc33b3d5-0525-476a-8c98-401131ab1f93
type: 'card'
entityType: 'Artifact'
created: '2026-04-05T21:43:11.448739+00:00'
updated: '2026-07-13T20:19:49.936+00:00'
---

# Rimefang Alter
