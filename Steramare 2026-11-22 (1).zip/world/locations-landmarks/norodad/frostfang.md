---
id: bd9de5f1-5e54-44ec-a203-5bda7589a667
type: 'card'
entityType: 'Location'
aliases: ['Frostfang']
created: '2026-02-10T19:13:25.341816+00:00'
updated: '2026-07-13T20:19:49.936+00:00'
---

# Frostfang

*Also known as Frostfang*
