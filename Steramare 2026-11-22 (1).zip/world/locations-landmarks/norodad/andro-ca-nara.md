---
id: e1c86c85-60c2-4cc1-995d-8f50ccad134d
type: 'card'
entityType: 'Location'
created: '2026-02-11T00:24:24.591287+00:00'
updated: '2026-07-13T20:19:49.936+00:00'
---

# Andró Ca'nara

**Kingdom:** [Norðdad](../../../world/kingdoms-regions/nor-dad.md)

[Andró Ca'nara](../../../world/locations-landmarks/norodad/andro-ca-nara.md) is the only forest in [Norðdad](../../../world/kingdoms-regions/nor-dad.md), which lies in the heart of the kingdom. This place is a heaven of sorts, since it is the only place where the temperature is moderate year-round, and snow is not present. 

Traditionalist views of the Norodade have made this a holy site, where it is only visited by the public for burial traditions for deceased Chieftans or [Jökullverd](../../../world/factions/jokullverd.md).
