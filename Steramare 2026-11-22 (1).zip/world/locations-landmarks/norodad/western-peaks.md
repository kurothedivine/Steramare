---
id: abfd4c39-11c5-4fe0-97e9-9d4ff959126b
type: 'card'
entityType: 'Location'
created: '2026-02-11T00:31:26.410346+00:00'
updated: '2026-07-13T20:19:49.936+00:00'
---

# Western Peaks

The Western Peak’s are a North-Western mountain range between [Norðdad](../../../world/kingdoms-regions/nor-dad.md) and \_\_\_\_.
