---
id: 1209cb20-2b49-4977-b5f1-c73084b94b42
type: 'card'
entityType: 'Location'
created: '2026-02-11T01:22:08.393551+00:00'
updated: '2026-07-13T20:19:49.936+00:00'
---

# Gjöll's Teeth

**Ritual:** [Jökull's Proving](../../../world/festivals-rituals/jokull-s-proving.md)
