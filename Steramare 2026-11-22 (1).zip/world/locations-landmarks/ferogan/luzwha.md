---
id: cfe31c1a-4309-4402-9e91-e8394313628c
type: 'card'
entityType: 'City'
created: '2026-09-11T18:35:19.893226+00:00'
updated: '2026-10-01T04:56:33.246+00:00'
---

# Luzwha

**Location:** [Ferogan Empire](../../../world/kingdoms-regions/ferogan-empire.md)

## History

[Luzwha](../../../world/locations-landmarks/ferogan/luzwha.md) was a [Jinrami](../../../world/kingdoms-regions/jinrami.md) river city long before [Ferogan](../../../world/kingdoms-regions/ferogan-empire.md) ever set foot inside its walls, built where a bend in the water gave the [Jinrami](../../../world/kingdoms-regions/jinrami.md) merchant ships a great trading hub, and a perfect spot to stock up before venturing south towards the Serpentine Delta. The gardens, the curve of the streets, the shape of colorful rooftops all belonged to [Jinrami](../../../world/kingdoms-regions/jinrami.md) builders first, and none of that has had time to conform to the brutalist architecture you see in most [Ferogan](../../../world/kingdoms-regions/ferogan-empire.md) cities.

[Ferogan](../../../world/kingdoms-regions/ferogan-empire.md) took the city within the last generation in a border [conflict](../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md), one of many that spark between the two rival nations. Some people are old enough to remember the siege [Ferogan](../../../world/kingdoms-regions/ferogan-empire.md) laid on the Ashen Road. Its new name at least, serving as a mockery and reminder of how soldiers cladded in red stained steel scorched the north-western gate, razing around 30% of the city. Fergonian workers built a castle at the center of [Luzwha](../../../world/locations-landmarks/ferogan/luzwha.md) to assert their dominance, garrisoned the gates, and set their eyes on bloodletting [Jinrami](../../../world/kingdoms-regions/jinrami.md) culture they deemed crude. 

What has actually happened since is messier than expected. A generation has grown up under [Ferogan](../../../world/kingdoms-regions/ferogan-empire.md) rule with ties to [Jinrami](../../../world/kingdoms-regions/jinrami.md) culture, retired soldiers started to marry into [Jinrami](../../../world/kingdoms-regions/jinrami.md) families, and slowly the two ways of living had stared to awkwardly and unevenly, meld together. Call it a blend if you’d like. Some in [Luzwha](../../../world/locations-landmarks/ferogan/luzwha.md) would call it something closer to a healing wound that’s waiting to be infected.

[Ferogan's](../../../world/kingdoms-regions/ferogan-empire.md) ownership of the city is not in question and never has been. What is less settled is how the newest generation of [Luzwha](../../../world/locations-landmarks/ferogan/luzwha.md), raised inside a city its grandparents remember losing, will feel about that as the ceasefire that ended the larger war grows shakier by the year.

## Districts:

Starbloom:

Cherry Wall:

Choudheart Gate:

Ashen Road:

 The Well:

Red Mile:

East Slums:

## Points of Interest

Violet Gardens:

Festival Grounds:

## Map Permalink

[https://watabou.github.io/city-generator?size=57&seed=923051886&name=](https://watabou.github.io/city-generator?size=57&seed=923051886&name=Luzwha&citadel=1&urban_castle=1&plaza=1&temple=0&walls=1&shantytown=0&coast=0&river=1&greens=1&gates=-1)[Luzwha](../../../world/locations-landmarks/ferogan/luzwha.md)[&citadel=1&urban\_castle=1&plaza=1&temple=0&walls=1&shantytown=0&coast=0&river=1&greens=1&gates=-1](https://watabou.github.io/city-generator?size=57&seed=923051886&name=Luzwha&citadel=1&urban_castle=1&plaza=1&temple=0&walls=1&shantytown=0&coast=0&river=1&greens=1&gates=-1)
