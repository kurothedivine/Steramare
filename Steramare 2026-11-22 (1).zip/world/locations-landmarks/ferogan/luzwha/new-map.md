---
id: f4b7b1b5-9a66-4ae6-9275-301a519d0df6
type: 'map'
created: '2026-09-11T18:57:47.766853+00:00'
updated: '2026-09-11T18:58:03.093+00:00'
---

# New Map

*A map — open it in vvd to view it.*

map /api/media/371281d6-2edb-46f9-aa4d-511232b02611 371281d6-2edb-46f9-aa4d-511232b02611
