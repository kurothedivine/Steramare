---
id: 19a6cc4e-c215-467a-ab98-d146ad2dd1a7
type: 'card'
entityType: 'City'
created: '2026-07-18T18:30:18.056755+00:00'
updated: '2026-07-18T20:55:33.606+00:00'
---

# Opeslya

**Kingdom:** [Ferogan Empire](../../../world/kingdoms-regions/ferogan-empire.md)
