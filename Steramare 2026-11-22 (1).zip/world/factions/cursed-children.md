---
id: 8dc9266b-90e7-42cc-ab00-be6a4fa8a9de
type: 'card'
entityType: 'Faction'
created: '2026-04-28T04:38:51.654805+00:00'
updated: '2026-07-18T21:07:21.933+00:00'
---

# Cursed Children

**Noble House:** [House Chernoglaz](../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md)  
**Faction:** [Zaali](../../world/factions/zaali.md)
