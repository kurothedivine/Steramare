---
id: 122be507-f032-4cdd-bde4-8cfa742c9661
type: 'card'
entityType: 'Cult'
created: '2026-02-10T05:09:13.554791+00:00'
updated: '2026-11-07T18:54:36.917+00:00'
---

# Zaali

**Magic System:** [Necromancy](../../world/magic/necromancy.md)

## Overview

The [Zaali](../../world/factions/zaali.md) began during [the Lich King's](../../world/lore/legendary/the-lich-king.md) reign as his cult following—zealots who saw him as a god of death and transformation. But in the 350 years since [The Shattering](../../world/lore/legendary/the-shattering.md), they have evolved into something more complex and fractured.

Today, "[Zaali](../../world/factions/zaali.md)" is an umbrella term for dozens of disparate cells, sects, and individual practitioners who share only loose ideological connections. The devout [Zaali](../../world/factions/zaali.md) worship [the Lich King](../../world/lore/legendary/the-lich-king.md) as a deity. Others study his work academically and want to continue his research. Some seek to resurrect him. And some use the [Zaali](../../world/factions/zaali.md) name as cover for their own dark ambitions.

## Organizational Structure

**The ****Hierarchy (Pre-Shattering)**** During **[the Lich King's](../../world/lore/legendary/the-lich-king.md) reign, the [Zaali](../../world/factions/zaali.md) had clear structure:

- [The Lich King](../../world/lore/legendary/the-lich-king.md) - Undisputed master

- - His inner circle of powerful necromancers and soldiers

- - Commanders of undead legions

- - Practicing necromancers and dark scholars, mostly grunt forces

- - Non-magical devotees who served logistical roles

**After **[the Lich King's](../../world/lore/legendary/the-lich-king.md) death, the [Zaali’s](../../world/factions/zaali.md) clear structure started to dwindle. Some took this power vacuum to attempt to become the next [Lich King](../../world/lore/legendary/the-lich-king.md), while others completely abandoned his teachings. Today it operates more like a decentralized network, with many falling into one or more [Zaali](../../world/factions/zaali.md) subsections:

- **Orthodox****: **These individuals believe [the Lich King](../../world/lore/legendary/the-lich-king.md) isn’t properly dead, and actively prepare for his resurrection. They preserve his teachings and seek artifacts from his reign. Most dangerous and organized.

- **Philosophers: **Study [necromancy](../../world/magic/necromancy.md) as an intellectual pursuit. They believe death magic reveals fundamental truths about reality. Many are scholars who've been driven underground by anti-[necromancy](../../world/magic/necromancy.md) laws, or practice in plain sight.

- **Vengeful: **Joined seeking power to right personal wrongs. They care little for [the Lich King's](../../world/lore/legendary/the-lich-king.md) philosophy but use [Zaali](../../world/factions/zaali.md) connections to learn forbidden magic and techniques for revenge or personal gain. Usually the most common group of newly recruited [Zaali](../../world/factions/zaali.md) - and often the most inept. 

- Nihilists: Embrace [the Lich King's](../../world/lore/legendary/the-lich-king.md) view that life is suffering. They seek undeath for themselves or wish to "liberate" others through death. Most of these are chaotic evil entities with the primary goal of causing mayhem and destruction.

- Opportunists: Use the [Zaali](../../world/factions/zaali.md) name and symbols to legitimize criminal enterprises. [Necromancy](../../world/magic/necromancy.md) is merely a byproduct of their actual goals of [wealth](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) and power.

- Heretics: Believe [the Lich King's](../../world/lore/legendary/the-lich-king.md) methods were flawed and primitive. They seek to perfect [necromancy](../../world/magic/necromancy.md), surpass him, or use his knowledge for different ends entirely.

## How They Operate

The [Zaali](../../world/factions/zaali.md) function as a secret society with no central leadership. Individual cells operate independently, connected through:

- **Symbols and Recognition: All **[Zaali](../../world/factions/zaali.md) know certain signs, phrases, and rituals that allow them to identify fellow members. A particular arrangement of bones, a phrase spoken in ancient tongue, or a specific hand gesture can reveal allegiance.

- **The ****Dead Letters**: Messages passed through necromantic means—written on scrolls that burn to ash and reform elsewhere, whispers carried by bound spirits, or knowledge transferred through brief possession of corpses. This allows communication while avoiding detection.

- **Safe Houses: Hidden throughout **[Steramare](../../world/lore/legendary/origins-of-steramare.md), marked with symbols visible only to those who know what to look for. Often located in crypts, abandoned churches, or beneath graveyards.

- **The ****Black Markets****: **[Zaali](../../world/factions/zaali.md) control much of the trade in forbidden artifacts, dark magic components, and necromantic texts. Even non-[Zaali](../../world/factions/zaali.md) who seek such items must eventually deal with them.

- **Initiations**: Joining requires proof of commitment—usually performing a forbidden act (raising a corpse, binding a spirit, desecrating something holy) witnessed by established members. This ensures loyalty through mutual blackmail.

## Why People Join

- **Power Through Knowledge: **[Necromancy](../../world/magic/necromancy.md) is forbidden, which makes it valuable. Those willing to break taboos gain access to magic others fear to touch.

- **Grief and Loss: Many join after losing loved ones, desperate to bring them back or at least speak with them one final time. The **[Zaali](../../world/factions/zaali.md) exploit this grief ruthlessly.

- **Philosophical Conviction: Some genuinely believe in **[the Lich King's](../../world/lore/legendary/the-lich-king.md) teachings about death being superior to life. They see themselves as enlightened rather than evil. 

- **Revenge: The **[Zaali](../../world/factions/zaali.md) offer power to those wronged by society. The dispossessed, the marginalized, the betrayed—all find the promise of fulfilling their wishes intoxicating.

- **Academic Curiosity**: Scholars fascinated by forbidden knowledge, believing that banning an entire school of magic is intellectual cowardice. Many convince themselves they're "just researching."

- **Nowhere Else to Go: Those caught practicing **[necromancy](../../world/magic/necromancy.md), even accidentally, are often executed. The [Zaali](../../world/factions/zaali.md) are the only refuge for such people.

## Objectives of the Zaali

- **Necromantic Research**: Pushing the boundaries of death magic. Seeking to perfect resurrection, create more powerful undead, or achieve lichdom themselves.

- **Artifact Recovery: Hunting relics from **[the Lich King's](../../world/lore/legendary/the-lich-king.md) reign. His personal effects, weapons, spell books, and pieces of his destroyed soul are priceless to them.

- **Recruitment**: Constantly seeking new members, especially talented mages who've been marginalized by society.

- **Undermining Anti-**[Necromancy](../../world/magic/necromancy.md)** Laws: Working to normalize death magic, either through propaganda, bribery, or demonstration of its "beneficial uses."**

- **Preparing for the Return: ****Orthodox**** **[Zaali](../../world/factions/zaali.md)** believe **[the Lich King](../../world/lore/legendary/the-lich-king.md) left clues for his resurrection scattered across [Steramare](../../world/lore/legendary/origins-of-steramare.md). They seek these pieces obsessively.

- **Criminal Enterprise**: Using undead labor for smuggling, assassination, and other illegal activities. A corpse can't testify, after all.

## Zaali in Society

Most [Zaali](../../world/factions/zaali.md) live double lives. By day they could be gatekeepers and historians that have easy access to bodies and forbidden texts. Or [Zaali](../../world/factions/zaali.md) could be wealthy nobles or priests that are in positions of power to make the rules bend in their favor. While they are uncommon, the [Zaali](../../world/factions/zaali.md) are definitely real. They gather in secret, practice in hidden chambers, and leave no evidence. Witch hunters and [Hagiser](../../world/factions/hagiser.md) elites spend careers tracking them with limited success.
