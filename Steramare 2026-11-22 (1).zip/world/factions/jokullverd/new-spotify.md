---
id: 3bd6c25c-531d-4fbd-a11d-f8f941a327d2
type: 'spotify-embed'
created: '2026-11-09T01:59:40.592577+00:00'
updated: '2026-11-09T02:00:48.187+00:00'
---

# New Spotify

*A spotify embed — open it in vvd to view it.*
