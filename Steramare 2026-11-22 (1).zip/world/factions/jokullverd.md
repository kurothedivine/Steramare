---
id: 20988053-e4a2-40d7-83f9-88d48b094b18
type: 'card'
entityType: 'Guild'
aliases: ['The Brotherhood', 'Sheperds of the Snowline']
created: '2026-02-10T08:53:46.415715+00:00'
updated: '2026-11-09T02:01:18.814+00:00'
---

# Jökullverd

*Also known as The Brotherhood, Sheperds of the Snowline*

## The Hunt Beneath the Aurora

> ## Fairy tales do not tell children the dragons exist. Children already know that dragons exist. Fairy tales tell children the dragons can be killed.

The Jökullverd are the elite warriors of [Norðdad](../../world/kingdoms-regions/nor-dad.md), a brotherhood sworn to the cold reaches where the roads end and the monsters begin. They spend most of their years in the northern lands, tracking and killing the things that stalk the snowline. They have a close connection to the gods and spirits of the land, often forgoing advanced means of production and innovation for more traditional means. Few outsiders have seen one up close, and fewer have lived to tell the tale.

## The Rite of a Warrior

Neither name nor blood grants entry. Every candidate must survive a coming of age ritual at the [Rimefang Alter](../../world/locations-landmarks/norodad/rimefang-alter.md), a trial that is closely guarded. Those who return are changed, and are greatly respected in [Norðdad](../../world/kingdoms-regions/nor-dad.md).

## Duties of the Brotherhood

The Jökullverd have four main duties they uphold:

- Due to Norodad's small population, they stand as the primary elite military force against foreign national threats

- To serve as the Sheperds of the Snowline, they cull monstrous threats in more remote regions of  Norodad

- To keep the gods of the north tame, they often conduct rituals and festivals to honor them. Some are public facing, others are not. 

- In extreme cases, they work beyond the borders of [Norðdad](../../world/kingdoms-regions/nor-dad.md).

## Beyond the Border

[Norðdad](../../world/kingdoms-regions/nor-dad.md) keeps its gates narrow and its customs old, so when the Jökullverd cross the frontier, something has gone wrong. They reclaim relics that [Norðdad](../../world/kingdoms-regions/nor-dad.md) considers its own and carry out quiet operations against its enemies. If they have arrived at your doorsteps, diplomacy is far out of question. 

> ## *"The snow melts and forgets, we do not."*

## Inspiration

[New Spotify](../../world/factions/jokullverd/new-spotify.md)
