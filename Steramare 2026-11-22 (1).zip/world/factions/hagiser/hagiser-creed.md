---
id: 85ff2134-0b1d-4957-a410-65564eadc99d
type: 'card'
entityType: 'Religion'
created: '2026-02-10T08:15:12.170705+00:00'
updated: '2026-11-08T20:35:27.157+00:00'
---

# Hagiser Creed

## Overview

The [Hagiser Creed](../../../world/factions/hagiser/hagiser-creed.md) is the code of conduct for the [Hagiser](../../../world/factions/hagiser.md). These [templars](../../../world/factions/hagiser.md) follow these tenets, which are named after the core values of [The Fated Four](../../../world/lore/legendary/the-fated-four.md).

## Tenets

- **Justice**: Never turn a blind eye to evil or corruption.

- **Sacrifice**: The weak shall always be protected, even at the cost of oneself. Do not expect compensation for your actions, nor should you exploit others. 

- **Hope:** Against overwhelming odds, never give up. Fight to the last man if necessary.

- **Fervor: **Rage is a natural emotion of life, but it must be channeled to a divine purpose.
