---
id: 260e413f-b85a-4070-8b00-7eb55b5c1666
type: 'card'
entityType: 'Character'
aliases: ['Corpsemother', 'Corvina']
created: '2026-07-18T20:05:41.322037+00:00'
updated: '2026-10-15T18:19:21.11+00:00'
---

# Corvina Grey

*Also known as Corpsemother, Corvina*

**Faction:** [Zaali](../../../world/factions/zaali.md)

## The Lich's Long Forgotten Lover

[Corvina](../../../world/factions/zaali/corvina-grey.md) had always loved wholeheartedly , the way other people fear expression of love without the sense to hold anything back for herself. As a girl she gave that devotion to a nurse who left the household within a year, then to a promise a childhood friend forgot within a season, and each time something in her narrowed a little further, learning that people leave, forget and disappoint. [The Lich King](../../../world/lore/legendary/the-lich-king.md) never decided to abandon her. By the time she found his writings stuffed on a shelf it did not belong on, she had already spent years perfecting the kind of love that asks for nothing back. His pages gave her somewhere to finally place the love she’s been desperately wanting to share.

What started as study stopped being study quickly, though she would not have called it that at the time. She began answering him in the margins, first as curious commentary and then as conversation, and eventually as though a question he had posed three hundred years ago had been waiting only for **her **to arrive and finish it. She grew obsessive of details no one else valued: the particular slant of his signature, the way he circles his i’s and bows his j’s, and a single surviving letter to a lover history barely bothered to name. That wife became the first person [Corvina](../../../world/factions/zaali/corvina-grey.md) ever hated without having met her, and she spent an unreasonable number of nights convinced the histories had the marriage wrong. One stormy night, after locking herself in her chambers dreaming of the Lich’s cold touch embracing her, she had an epiphany. **She **was the one being described, simply misplaced by a few hundred years.

This idea filled the void that she has had in her this whole time, the missing link to her existence. This sweetness held until a fellow archivist, a man who had access to the same restricted stacks made the mistake of publishing a paper contradicting her interpretation of the lover’s letter. He began quietly losing pages from his own research. Then his notes. Then, for a short while, his position at the university, and after that no one thought to ask what became of him at all. [Corvina](../../../world/factions/zaali/corvina-grey.md) never spoke of it, and those who knew her only through her manners found the accusation impossible to credit, since she still asked after people's health and remembered the names of their children. It was the people closest to her books who learned that the softness and the danger came from the exact same place.

Leaving her noble family in [Ruida](../../../world/kingdoms-regions/republic-of-ruida.md) barely registered as a loss for the family. She was still unmarried, and her obsession with [the Lich King](../../../world/lore/legendary/the-lich-king.md) had diminished her marks on her exams to where she could never be a proper mage for her family’s high expectations. What she wanted by then was not freedom from her family so much as an audience, since a marriage only half witnessed by the person living it needs somewhere else to be believed, and the last scraps of the [Zaali](../../../world/factions/zaali.md) gave her both believers and a name to build around. She did not think of it as recruiting. She thought of it as finally introducing people to her husband. Whatever the [Zaali](../../../world/factions/zaali.md) were before she found them, they have not been that since. What they are now is a court assembled for a wedding still waiting to happen, run by a woman who will tell you that she loves him more than her own name, and mean it in a way that should probably frighten you more than it does.
