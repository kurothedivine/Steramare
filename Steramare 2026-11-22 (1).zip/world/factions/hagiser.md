---
id: 346231f3-be43-4dd6-ab04-f8e6dfd731bb
type: 'card'
entityType: 'Order'
aliases: ['Templars']
created: '2026-02-10T04:25:10.188974+00:00'
updated: '2026-07-16T17:14:01.983+00:00'
---

# Hagiser

*Also known as Templars*

## Background

The [Hagiser](../../world/factions/hagiser.md) is an order of holy [templars](../../world/factions/hagiser.md), early established when the [Lich King](../../world/lore/legendary/the-lich-king.md) reigned terror across [Steramare](../../world/lore/legendary/origins-of-steramare.md). Initially compromised by soldiers funded by several kingdoms in its early roots, it is now mostly comprised of orphans and volunteers. 

## Structure

The [Hagiser](../../world/factions/hagiser.md) go through an apprenticeship, journeyman, knight and master path as they learn combat techniques, the holy arts, and creating a name for themselves. 

They follow a creed called the \_\_\_\_, which is directly influenced by the [The Fated Five](../../world/lore/legendary/the-fated-four.md).
