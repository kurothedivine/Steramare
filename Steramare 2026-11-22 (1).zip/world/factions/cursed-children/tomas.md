---
id: 0b0174ac-6548-4939-a0bd-4ab7264c4f02
type: 'card'
entityType: 'Character'
created: '2026-07-20T18:24:04.987546+00:00'
updated: '2026-07-21T16:04:20.2+00:00'
---

# Tomas

**Faction:** [Cursed Children](../../../world/factions/cursed-children.md)
