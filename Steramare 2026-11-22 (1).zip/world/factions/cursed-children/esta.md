---
id: 3530f7c9-c7a7-451e-bace-03e3ba7762ef
type: 'card'
entityType: 'Character'
created: '2026-07-20T16:56:40.880765+00:00'
updated: '2026-07-21T16:04:20.2+00:00'
---

# Esta

**Faction:** [Cursed Children](../../../world/factions/cursed-children.md)
