---
id: 9cb28bcf-0440-4b96-811e-1bc0bffedfaf
type: 'card'
entityType: 'Character'
created: '2026-07-18T21:04:53.849831+00:00'
updated: '2026-11-09T02:04:24.539+00:00'
---

# Jane Schädler

**Faction:** [Cursed Children](../../../world/factions/cursed-children.md)  
**City:** [Nochstadt](../../../world/kingdoms-regions/nochstadt.md)  
**Book:** [The Diary of Jane Schädler](../../../world/books/the-diary-of-jane-schadler.md)
