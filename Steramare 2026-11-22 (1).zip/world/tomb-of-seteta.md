---
id: b82e98e2-0e9e-4487-b3e6-8fc87a90ed46
type: 'card'
entityType: 'Dungeon'
created: '2026-10-13T18:21:44.038231+00:00'
updated: '2026-10-14T23:39:48.823+00:00'
---

# Tomb of Seteta

**Location:** [Jinrami](../world/kingdoms-regions/jinrami.md)

## Overview

## Trap Types

- Snakes or Entombed Skin Beetles falling from above, or crawling from tiles beneath

- Rooms filling with sand or water

- Spikes coming from walls

## Map

_Map of the Tomb of Seteta_

## Rooms

Room 1:

- Room is engraved with ancient images

- Two veiled statues with violet gems for eyes are morning, placed in a mourning positions. Removal of the gems or interacting with them causes the statues to animate and attack the party. 

- The west wall has a golden plaque engraved 

- "[Seteta](../world/kingdoms-regions/jinrami/seteta.md) coils beneath the desert's skin. Her pelt shimmers like sapphires drowned in sunfire. Flowers rise at the whisper of her presence. She speaks, and the sun answers from the clouded sky. Empires vanish, swallowed whole by her shifting sands"

Room 2:

- A pool of clear water lies in the room, surrounded by sand and weathered stones

- Anyone who drinks from it are magically compelled to keep drinking, and keep getting thirstier, they must make a roll to the dungeon's difficulty or suffer marking a stress. 

Room 3:

- Chamber with a massive statue of  a robed [human](../world/races/human.md), hood casted over is face

- Left hand has a scythe, right hand a chain with a sharp black blade hanging down into a circle indendation roughly eight inches wide

- 12 candles stand in regular intervals, all wicks are magically lit

- Riddle, holding the blade over any candles cause it flare up. Cause the room to get hotter, marking two stress if they are wrong. If not, lose 1 HP

- 

Room 4: Dead end room, players discover treasure here. Lead on for a secret entrance to the ritual room

Room 5:

- A  black crystal sits in the middle of the room, pulsating red. Within the crystal shows dim images of memories; brutal battles from the first person perspective. Touching the crystal lets those see the full horrors of  the memories, augmenting reality from their perspective.

- On Knowledge/Instinct pass the target resists the mental trauma from the images, and sees a memory clearly. It's from [Mattai's](../world/lore/gods-goddesses/mattai.md) perspective, calming down a crowd with ease, with [Seteta](../world/kingdoms-regions/jinrami/seteta.md) by his side. 

-  On Knowledge/Instinct fail player takes 3d6 magic damage.  Curses the target? They have visions later in the campaign of [Mattai's](../world/lore/gods-goddesses/mattai.md) memories wearing the crown.  Spend fear and use Knowledge/Instinct checks to cause target to have to resist visions, if failed mark a stress. 

- Tomb room, main sarcophagus engraved at the feet "Here lies Setata, mother of the dunes, lover of the sun." Make note of how the organ jars are around the room, but don't make too much of a notice towards it

- The sarcophagus is cracked open, fully opening it causes combat to ensue
