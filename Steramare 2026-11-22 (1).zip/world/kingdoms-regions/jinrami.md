---
id: 282ae0f0-b596-4728-83e0-5e028654bf3b
type: 'card'
entityType: 'Kingdom'
created: '2026-07-16T17:03:52.929209+00:00'
updated: '2026-10-13T17:33:47.384+00:00'
---

# Jinrami

## Overview

Long before a caravan enters the arid land, the wind carries forward scents of myrrh, orange blossom, and hot gold dust, announcing itself through the nose before it ever reaches the eye. Following the scent comes color. Domes the shade of baked clay and burnished copper rise out of a green river valley before the land continues into a golden coastline, the ocean seperating the coast from its former body of the [Scorchlands](../../world/kingdoms-regions/scorchlands.md). [Jinrami](../../world/kingdoms-regions/jinrami.md) sits in that seam between fertile and ferocious, and it has built an empire of beauty at the large oasis-like landmass.

## Gold From the Mountain

 [Jinrami](../../world/kingdoms-regions/jinrami.md) built their [wealth](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) thread by thread, drop by drop, stone by stone, and the crown watches over three trades that serve as the kingdom’s lifeline.

- Silk grown in the river valleys, spun fine enough that a full bolt folds down to fit inside a closed fist.

- Perfume oils distilled from stubborn desert flowers, concentrated enough that a single vial can scent a hall for a week

- Gold pulled from veins that run close to the surface in the same mountains that have kept every [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) legion out.

Textiles, perfume, and gold. These three exports has created a treasury grander than any other kingdom of [Steramare](../../world/lore/legendary/origins-of-steramare.md).

## Gold and Iron

[Ferogan](../../world/kingdoms-regions/ferogan-empire.md) believes power is based on how strong your armies are, while the [Jinrami](../../world/kingdoms-regions/jinrami.md) believe power is based on your appearance and [wealth](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md).  

That single disagreement explains almost everything else between them. Where [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) sorts its people into academies and specialties, [Jinrami](../../world/kingdoms-regions/jinrami.md) raises artisans and entertainers,  and a master weaver receives the same reverence [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) reserves for a general. Where [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) calls its expansion a correction, [Jinrami](../../world/kingdoms-regions/jinrami.md) calls it theft wearing paperwork, and turns away every treaty that arrives under a [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) seal. Offers of marriage have crossed the [Kharsk Mountains](../../world/kharsk-mountains.md) more than once, quiet proposals meant to accomplish what the legions could not. Every one has come back unopened.

The mountains have kept [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) out for generations. [Jinrami](../../world/kingdoms-regions/jinrami.md) intends to make sure its pride does the same, long after the mountains eventually don't.

## The Jindara Line

The crown belongs to [House Jindara](../../world/house-jindara.md) , and has since the royal archives were created.  The dynasty traces itself to a ruler the old texts simply call [Mattai](../../world/lore/gods-goddesses/mattai.md), a deity of sorts who’s said to have walked out of the [Scorchlands](../../world/kingdoms-regions/scorchlands.md) with the sun still caught in her skin and never quite let go of it.

Every [Balik](../../world/kingdoms-regions/jinrami/balik.md) since has been measured against that image, sometimes literally. Succession in [Jinrami](../../world/kingdoms-regions/jinrami.md) is not only a matter of blood. An heir must be seen and approved by the court before the crown is offered, and the histories remember at least two princes quietly moved down the line for reasons the palace never wrote down but everyone understood anyway.

## The Measure of a Person

Outsiders tend to dislike the vanity of the [Jinrami](../../world/kingdoms-regions/jinrami.md), looking at it as superficial. 

In [Jinrami](../../world/kingdoms-regions/jinrami.md), how a person carries themselves is treated as information. Scars are read like a record of service. Jewelry and cloth marks trade, social status, and marriage in a non-verbal language every citizen learns as a child. Cosmetic paint is as crucial as punctuation, a way of stating intent before a word gets spoken. A soldier who returns from the Jinwei Ford with her paint still perfect is trusted less than one who returns with it ruined, because the ruined paint is proof she was actually there.

None of this makes [Jinrami](../../world/kingdoms-regions/jinrami.md) people shallow. It means they built a whole vocabulary out of appearance long before they trusted words to carry the same weight.
