---
id: ee0f8b8b-52cd-4674-b4f1-ced80075b9f4
type: 'card'
entityType: 'Kingdom'
aliases: ['Ruida']
created: '2026-04-07T01:38:08.53126+00:00'
updated: '2026-11-22T18:33:58.517+00:00'
---

# Republic of Ruida

*Also known as Ruida*

## Academia and the State

The line between [Ruida's](../../world/kingdoms-regions/republic-of-ruida.md) government and its academic institutions is purely administrative. The [Collegiate Academies](../../world/kingdoms-regions/republic-of-ruida/collegiate-academies.md) are state institutions funded by the [Council](../../world/kingdoms-regions/republic-of-ruida/government/magus-council.md), staffed by mage-nobles, and attended exclusively by those of sufficient standing and demonstrated ability. Graduating with high honors from a [Collegiate Academy](../../world/kingdoms-regions/republic-of-ruida/collegiate-academies.md) is the single most reliable path to a [Council](../../world/kingdoms-regions/republic-of-ruida/government/magus-council.md) seat, a land grant, or a prestigious appointment. Graduating with middling marks still opens doors that no amount of merchant [wealth](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) can unlock for those born without magic.

The Academies also serve as [Ruida's](../../world/kingdoms-regions/republic-of-ruida.md) primary engine of arcane research, which is where [the Republic's](../../world/kingdoms-regions/republic-of-ruida.md) official purpose and its actual behavior diverge most visibly. The stated mission: "The betterment and advancement of arcane knowledge for the good of all" is genuine in the context that enormous resources are dedicated to it and real discoveries are made regularly. It is also conducted almost entirely for the benefit of the people already at the top of the system, published in journals that non-mages cannot read in libraries that non-mages cannot enter, and funded by an economy whose lower tiers are kept precisely where they are so that the upper tiers can afford their equipment, their research, and their extraordinarily lavish academic galas.

In the [Council](../../world/kingdoms-regions/republic-of-ruida/government/magus-council.md) is [Ruida's Twelve](../../world/kingdoms-regions/republic-of-ruida/government/ruida-s-twelve.md), a group that serves as a higher elected body for more executive decisions. Led by the [Grand Magus](../../world/kingdoms-regions/republic-of-ruida/government/grand-magus.md), they are among the wealthiest and strongest families in [the Republic](../../world/kingdoms-regions/republic-of-ruida.md). 

## Economy and Export

[Ruida's](../../world/kingdoms-regions/republic-of-ruida.md) economy runs on three things: enchanted goods, arcane services, and controlled knowledge. [The Republic](../../world/kingdoms-regions/republic-of-ruida.md) is the premier source of enchanted materials and magical expertise in [Steramare](../../world/lore/legendary/origins-of-steramare.md) — everything from warded armor and spelled agricultural tools to consultancy for foreign governments seeking magical counsel. Price floor and ceilings are set by the [Council](../../world/kingdoms-regions/republic-of-ruida/government/magus-council.md), access is managed by licensed noble trading houses, and the margins are extraordinary.

The non-magical merchant class handles the physical logistics of this trade — shipping, warehousing, negotiation with foreign buyers — and grows wealthy doing it, in the strictly limited way that wealthy non-mages are permitted to grow. They fund the system that excludes them from full participation in it, which is an arrangement the [Ruida's Twelve](../../world/kingdoms-regions/republic-of-ruida/government/ruida-s-twelve.md) finds entirely satisfactory.

Foreign visitors are welcomed as customers and viewed with calibrated suspicion as anything else. A foreign dignitary with gold to spend will be received with warmth and shown [the Republic's](../../world/kingdoms-regions/republic-of-ruida.md) most impressive public face — the grand architecture of the capital, the curated lower floors of the public libraries, the carefully selected demonstrations of arcane craft that are designed to impress without revealing anything proprietary. A foreign scholar hoping to access the deeper collections will find the process of obtaining sponsorship long, expensive, and ultimately reliant on what the [Council](../../world/kingdoms-regions/republic-of-ruida/government/magus-council.md) decides it wants in return.

[The Republic](../../world/kingdoms-regions/republic-of-ruida.md) does not consider this xenophobia, merely “exercised discretion”.

## Magic and Blood
