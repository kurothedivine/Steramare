---
id: 977e79e7-a38f-490a-807e-8968b7c458e0
type: 'card'
entityType: 'Academia'
created: '2026-07-13T21:15:29.485025+00:00'
updated: '2026-07-14T22:51:09.739+00:00'
---

# Collegiate Academies
