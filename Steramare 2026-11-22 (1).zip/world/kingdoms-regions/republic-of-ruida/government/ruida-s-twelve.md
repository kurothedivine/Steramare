---
id: 046246c2-7bed-4d23-986f-d4d579311346
type: 'card'
entityType: 'Government'
aliases: ['The Twelve']
created: '2026-04-26T19:35:20.001466+00:00'
updated: '2026-07-14T22:51:09.739+00:00'
---

# Ruida's Twelve

*Also known as The Twelve*

**Kingdom:** [Republic of Ruida](../../../../world/kingdoms-regions/republic-of-ruida.md)
