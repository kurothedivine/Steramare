---
id: 65850dc5-b26d-4518-9aff-425b569042c2
type: 'card'
entityType: 'Government'
aliases: ['Council']
created: '2026-04-07T01:35:39.783465+00:00'
updated: '2026-07-14T22:51:09.739+00:00'
---

# Magus Council

*Also known as Council*

**Kingdom:** [Republic of Ruida](../../../../world/kingdoms-regions/republic-of-ruida.md)
