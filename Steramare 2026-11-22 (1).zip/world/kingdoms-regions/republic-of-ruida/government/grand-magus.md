---
id: a6703b02-d1ca-4798-b5f1-d980c267b0ec
type: 'card'
entityType: 'Government'
created: '2026-04-07T01:36:38.916836+00:00'
updated: '2026-07-14T22:51:09.739+00:00'
---

# Grand Magus

**Kingdom:** [Republic of Ruida](../../../../world/kingdoms-regions/republic-of-ruida.md)
