---
id: 4ab0db52-c651-408e-8b05-6c063ccddbac
type: 'card'
entityType: 'Kingdom'
aliases: ['Ferogan']
created: '2026-07-13T20:20:47.162793+00:00'
updated: '2026-10-13T17:33:46.69+00:00'
---

# Ferogan Empire

*Also known as Ferogan*

## Overview

[Ferogan](../../world/kingdoms-regions/ferogan-empire.md) does not conquer, it corrects. That is the line carved over the Senate doors in the capital, and every [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) envoy repeats some version of it to the client kings and merchant [councils](../../world/kingdoms-regions/republic-of-ruida/government/magus-council.md) who find imperial banners suddenly flying over their harbors. The empire calls itself a steadying hand. Everyone it has steadied calls it something else. Both are true at once, which is more or less the whole philosophy of the place. Strength decides who is right, and [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) has simply arranged to stay strong.

## Origins: Two Fires

Before [the Shattering](../../world/lore/legendary/the-shattering.md), [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) was a cold, stubborn province, known for iron mines and for refusing to bow to anyone who asked nicely. When [the Shattering](../../world/lore/legendary/the-shattering.md) tore the old order apart, most nations spent that first chaos looking for someone to blame. [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) spent it looking for someone to feed.

Grain convoys reached the ruined border towns before soldiers did. Then roads were rebuilt, and the roads needed guards, and the guards needed paying, and paying meant taxing, and taxing meant governing. By the time anyone thought to object, the province that had merely survived [the Shattering](../../world/lore/legendary/the-shattering.md) had quietly become the empire administering half the wreckage around it. This was the first wave, dressed up as rescue to the realm that most politicians ate up.

[The War Against the Living](../../world/lore/legendary/the-war-against-the-living.md) did not end that pattern, it sharpened it. [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) fought through it the same as its neighbors did, but its senators walked away from the wreckage with a colder, more effective version of the old pitch. Submit now, or face something like that again, alone. Fear recruits faster than famine ever did, and the second wave of [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) expansion has been built on it ever since.

## The Three Aspects

[Ferogan](../../world/kingdoms-regions/ferogan-empire.md) is ruled, in theory, by three elected Aspects who serve for life. In practice, life tends to be fleeting and very negotiable. Aspects have been deposed, exiled, quietly poisoned, or simply chased out of the capital by a crowd that changed its mind, and the empire has a long memory for every one of those endings without ever revising the job description. Each Aspect governs one part of the state.

- [Glory](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) serves as the commander-in-chief of the army and the military academies.

- [Conflict](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) presides over the Senate and civil law of the land. 

- [Wealth](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) oversees the treasury, trade, and tribute from vassal states.

The three rarely agree, and [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) seems to prefer it that way. A government that argues with itself is harder for outsiders to bribe all at once.

## Sitting Aspects, 160 AS

[Amata](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/amata.md), [Conflict](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md): The people adore her, and the story everyone tells about why starts with an execution. She beheaded [Ilarius](../../world/kingdoms-regions/ferogan-empire/government/ilarius.md) during a senate hearing, and walked away from it without so much as a formal charge. The peasants of [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) revere her like a goddess of the people,

[Varya](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/varya.md)**, **[Glory](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md)**:  **They call her** **[the Flame of Ferogan](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/varya.md), and she earned the name the hard way. Top graduate of [Atacella Academy](../../world/kingdoms-regions/ferogan-empire/military-academies/atacella-infantry-academy.md), she climbed into the [Kharsk Mountains](../../world/kharsk-mountains.md) as a cadet and came back down with a scale of a dragon as a shield, and doused in blood that did not belong to her. 

[Helias Vulgas](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/helias-vulgas.md)**, **[Wealth](../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md)**: ** Old blood from the Vulgas family, with three generations of Aspects behind him and a reputation for being nearly impossible to outwit. He is famous around the capital for card tables and quiet mind games, and diplomats have learned that losing to him at cards is often the safer outcome. 

## The Five Academies

[Ferogan](../../world/kingdoms-regions/ferogan-empire.md) treats war as a profession, and it sorts every recruit accordingly. Five academies, five specialties, no overlap.

- [Atacella Academy](../../world/kingdoms-regions/ferogan-empire/military-academies/atacella-infantry-academy.md) trains the infantry and elite guard units.

- [Goluus](../../world/kingdoms-regions/ferogan-empire/military-academies/goluus-academy-of-calvary.md) trains cavalry and the rare wild dragon riders.

- [Obsada](../../world/kingdoms-regions/ferogan-empire/military-academies/obsada-artillery-and-siege-academy.md)  handles artillery and siege craft.

- [Tenax](../../world/kingdoms-regions/ferogan-empire/military-academies/tenax-academy-of-support-and-logistics.md) runs logistics, supply routes, and military research.

- [Korvis](../../world/kingdoms-regions/ferogan-empire/military-academies/korvis-naval-academy.md) commands the fleet and naval resources.

Officers rarely transfer between academies once they graduate. [Ferogan](../../world/kingdoms-regions/ferogan-empire.md) admires specialists, and would rather field a superb siege engineer than an average generalist, winning wars by practicing a spear’s thrust or the loading of a trebuchet thousands of times.
