---
id: 56cc060a-21e4-478f-87dd-254716a913e0
type: 'card'
entityType: 'Kingdom'
created: '2026-02-24T02:24:30.149269+00:00'
updated: '2026-07-16T17:13:23.081+00:00'
---

# Scorchlands
