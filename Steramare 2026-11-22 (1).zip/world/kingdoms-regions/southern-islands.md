---
id: 07aa624f-3649-45e6-9215-692de690f8b5
type: 'card'
entityType: 'Kingdom'
created: '2026-04-04T18:43:01.72407+00:00'
updated: '2026-07-16T18:53:25.141+00:00'
---

# Southern Islands
