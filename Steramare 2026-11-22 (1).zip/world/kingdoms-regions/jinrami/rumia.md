---
id: 6299336a-b9a5-4be4-9c25-b0fcf20794f2
type: 'card'
entityType: 'Character'
created: '2026-07-16T17:09:11.515462+00:00'
updated: '2026-07-18T18:18:57.746+00:00'
---

# Rumia

**Kingdom:** [Jinrami](../../../world/kingdoms-regions/jinrami.md)
