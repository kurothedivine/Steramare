---
id: 5bc47d5e-7939-4fef-bd9b-d33cde678f6c
type: 'card'
entityType: 'Hamlet'
created: '2026-10-03T07:44:48.774587+00:00'
updated: '2026-10-03T07:45:29.463+00:00'
---

# Uṫṫa

**Location:** [Jinrami](../../../world/kingdoms-regions/jinrami.md)
