---
id: f417c667-5f23-46d4-89fa-24830b6e66fc
type: 'card'
entityType: 'Character'
created: '2026-10-13T19:05:25.012536+00:00'
updated: '2026-11-08T00:25:56.145+00:00'
---

# Seteta

## Notes

"Even next to the sun, she still shined brighter" -[Mattai](../../../world/lore/gods-goddesses/mattai.md)

## A Trail of Small Rebellions

## "Even next to the sun, she still shined brighter." -[Mattai](../../../world/lore/gods-goddesses/mattai.md)

Seteta was born to the dune [Katari](../../../world/races/katari.md), a people who read wind and footprints like a scholar reading a scroll. She was a good tracker and a better arguer. She had opinions on weather, on water rights, on the dignity of cats, and on any man who held his shoulders as if the world owed him a seat.

When hunters began to take the lowland villages, she did what nobody else would. She followed them. She learned their camps, their routes and their buyers, and she kept a tally on a knotted cord that grew longer every season. Her kin called her stubborn. Her enemies called her something they have never been brave enough to say twice.

## The Woman Who Argued With the Sun

Her version of the quarrel at the well is not the same as his. She admits she was wrong about the pelts. She does not admit she was wrong to shout.

After the burial in the sand, the two of them fell into the kind of friendship that is mostly insults. She mocked his glow. He tried to learn the [Katari](../../../world/races/katari.md) names for things. She taught him wrongly on purpose for a year, and he said nothing, and she eventually confessed because the silence was unbearable.

Their marriage stayed secret, and that was her decision. A [Katari](../../../world/races/katari.md) wife on the arm of the [Balik](../../../world/kingdoms-regions/jinrami/balik.md) would have made her people a prize to bargain over. So she kept a passive role as the king's advisor, keeping to her own tents, and he came to her at dusk with his light dimmed low. 

## Her Opinion of the Crown

She never trusted it, and she told him so, which was one of the reasons he loved her. The [Crown of Influence](../../../world/crown-of-influence.md) was built to bring [Katari](../../../world/races/katari.md) and [humans](../../../world/races/human.md) to the same table, and she wanted the same thing. She simply wanted it won by argument and not by suggestion. On the night he first wore it before her, she took it from his head and held it in both hands for a long moment.

"It works," she said. "That is what frightens me."

He did not answer. He knew she was right, and he spent the rest of his life agreeing.

## Trail Marks, as Left by Seteta

A tracker's shorthand, found scratched on stones near the old well:

- **Three lines and a circle:** *water, but not safe. Do not trust the sun's word.*

- **A crescent over a paw:** *my people were here. Leave something for them.*

- **A circle with rays, struck through:** *he found me. Ignore the previous marks.*

## What the Tomb Says She Became

Seteta died, and [Mattai](../../../world/lore/gods-goddesses/mattai.md) could not accept it. What came back through the threshold after the bargain with the Mistress of Death was not the woman who had argued with him at the well, but something the desert itself seemed to answer.

The inscription at the tomb's entrance describes her as she is now:

> *"Seteta coils beneath the desert's skin. Her pelt shimmers like sapphires drowned in sunfire. Flowers rise at the whisper of her presence. She speaks, and the sun answers from the clouded sky. Empires vanish, swallowed whole by her shifting sands."*

It reads like praise and like a warning, and it is both. The coiling is the first sign that her new shape is not a [Katari's](../../../world/races/katari.md) anymore. The sapphire pelt is the second, for in life she had silver hair and no such sheen. What remains of her has been rewritten by the rite, the sun that [Mattai](../../../world/lore/gods-goddesses/mattai.md) poured into it, and whatever the Mistress of Death added in payment.

She is still Seteta in the ways that matter most. She is also something the desert has begun to obey.
