---
id: 915289cb-fb8f-4686-88c2-45db141dc34d
type: 'card'
entityType: 'Government'
created: '2026-07-16T17:07:56.083661+00:00'
updated: '2026-07-16T17:14:57.447+00:00'
---

# Balik

## Overview

The [Balik](../../../world/kingdoms-regions/jinrami/balik.md) is the title used to refer to the king of [Jinrami](../../../world/kingdoms-regions/jinrami.md).
