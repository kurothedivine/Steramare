---
id: 10607b79-7471-4c1f-a177-54f6d5a23386
type: 'card'
entityType: 'Kingdom'
created: '2026-02-10T06:17:41.761885+00:00'
updated: '2026-11-08T22:27:32.634+00:00'
---

# Norðdad

## Description

[Norðdad](../../world/kingdoms-regions/nor-dad.md) is the kingdom to the north, surrounded by two large mountain ranges on the east and the west, which are better known as the [Eastern Peaks](../../world/locations-landmarks/norodad/eastern-peaks.md)  and the [Western Peaks](../../world/locations-landmarks/norodad/western-peaks.md).

## History & Culture

Being the mortal descendants of the Jotunn, the [Norðdade](../../world/races/nor-dade.md) people are heavily connected to the spirits and tradition of their lands. They heavily believe in gender roles, the cycle of rebirth, and warrior culture.

## Notable Locations

- The [Western Peaks](../../world/locations-landmarks/norodad/western-peaks.md) , where [Kotmani](../../world/lore/legendary/the-fated-four/kotmani.md) fought against the [Zaali](../../world/factions/zaali.md), splitting the mountain range in two using the \_\_\_\_\_.

- [Andró Ca'nara](../../world/locations-landmarks/norodad/andro-ca-nara.md), the only forest in [Norðdad](../../world/kingdoms-regions/nor-dad.md) where snow and ice are not present. Rumor says that the spirits of fallen warriors go to rest there. It is only visited for traditional burial rituals for deceased Chieftains or [Jökullverd](../../world/factions/jokullverd.md).
