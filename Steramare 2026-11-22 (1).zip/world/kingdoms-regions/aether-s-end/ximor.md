---
id: 7a6e8845-79cf-415d-88f7-6e6cb209fd86
type: 'card'
entityType: 'Character'
created: '2026-07-16T15:36:35.626801+00:00'
updated: '2026-07-18T18:19:01.87+00:00'
---

# Ximor
