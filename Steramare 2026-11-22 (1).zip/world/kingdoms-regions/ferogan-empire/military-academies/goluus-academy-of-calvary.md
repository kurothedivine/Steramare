---
id: 7ab7a6f1-be7c-48ce-9c44-5727d5c72835
type: 'card'
entityType: 'Academia'
aliases: ['Goluus']
created: '2026-07-16T19:18:43.428617+00:00'
updated: '2026-07-16T19:27:09.998+00:00'
---

# Goluus Academy of Calvary

*Also known as Goluus*

**Kingdom:** [Ferogan Empire](../../../../world/kingdoms-regions/ferogan-empire.md)
