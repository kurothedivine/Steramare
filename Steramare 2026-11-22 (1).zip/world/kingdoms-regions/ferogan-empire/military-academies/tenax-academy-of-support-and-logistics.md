---
id: ad07b690-f3eb-4345-8cee-c49baf72902c
type: 'card'
entityType: 'Academia'
aliases: ['Tenax', 'Tenax Academy']
created: '2026-07-16T19:23:29.324252+00:00'
updated: '2026-07-21T16:41:30.86+00:00'
---

# Tenax Academy of Support and Logistics

*Also known as Tenax, Tenax Academy*

**Location:** [Ferogan Empire](../../../../world/kingdoms-regions/ferogan-empire.md)
