---
id: 7faa8e66-1f9f-4fa5-8472-98891a19452f
type: 'card'
entityType: 'Academia'
aliases: ['Atacella Academy', 'Atacella']
created: '2026-07-14T23:05:15.067327+00:00'
updated: '2026-07-22T19:22:04.876+00:00'
---

# Atacella Infantry Academy

*Also known as Atacella Academy, Atacella*

**Kingdom:** [Ferogan Empire](../../../../world/kingdoms-regions/ferogan-empire.md)

## Overview

[Atacella Infantry Academy](../../../../world/kingdoms-regions/ferogan-empire/military-academies/atacella-infantry-academy.md) serves as one of the five major military academies in the [Ferogan Empire](../../../../world/kingdoms-regions/ferogan-empire.md). Specializing in infantry training and development, it is [Ferogan’s](../../../../world/kingdoms-regions/ferogan-empire.md) largest military academy. 

Notable graduates include [Varya](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/varya.md), [the Flame of Ferogan](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/varya.md).
