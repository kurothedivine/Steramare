---
id: 85b34960-97ec-4425-96bd-1e0faf4d82b6
type: 'card'
entityType: 'Academia'
aliases: ['Obsada']
created: '2026-07-16T19:16:22.212214+00:00'
updated: '2026-07-16T19:27:09.998+00:00'
---

# Obsada Artillery and Siege Academy

*Also known as Obsada*

**Kingdom:** [Ferogan Empire](../../../../world/kingdoms-regions/ferogan-empire.md)
