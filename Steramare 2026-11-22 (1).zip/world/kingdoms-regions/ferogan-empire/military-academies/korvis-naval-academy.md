---
id: 34afb9c0-3546-49bd-ab27-65cb425ea391
type: 'card'
entityType: 'Academia'
aliases: ['Korvis']
created: '2026-07-16T19:14:13.656039+00:00'
updated: '2026-07-16T19:27:09.998+00:00'
---

# Korvis Naval Academy

*Also known as Korvis*

**Kingdom:** [Ferogan Empire](../../../../world/kingdoms-regions/ferogan-empire.md)
