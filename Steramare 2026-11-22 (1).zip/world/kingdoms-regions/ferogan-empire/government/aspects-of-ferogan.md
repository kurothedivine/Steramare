---
id: d4663353-1db7-4268-96a9-413fcfd178b9
type: 'card'
entityType: 'Government'
aliases: ['Glory', 'Conflict', 'Wealth']
created: '2026-07-16T19:27:37.440455+00:00'
updated: '2026-07-21T17:08:39.766+00:00'
---

# Aspects of Ferogan

*Also known as Glory, Conflict, Wealth*

## Overview

The [Aspects of Ferogan](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) are three elected positions of [Ferogan](../../../../world/kingdoms-regions/ferogan-empire.md) are three elected positions of [Ferogan](../../../../world/kingdoms-regions/ferogan-empire.md), who have authoritarian control over the respective manners the constitution holds.   
  
These three aspects are named [Wealth](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md), [Conflict](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md), and [Glory](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md)  
  
[Conflict](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md): Serves as judiciary lead for senate meetings, can enact laws without senate approval during a state of emergency  
[Wealth](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md): controls the treasury finances, trade, etc  
[Glory](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md): serves as the chief in command for all military resources.
