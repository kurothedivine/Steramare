---
id: a27822cf-9842-477a-bcd2-36596a3cae31
type: 'card'
entityType: 'Character'
aliases: ['The Flame of Ferogan']
created: '2026-07-14T22:17:04.716627+00:00'
updated: '2026-08-05T22:07:12.579+00:00'
---

# Varya

*Also known as The Flame of Ferogan*

**Kingdom:** [Ferogan Empire](../../../../../world/kingdoms-regions/ferogan-empire.md)  
**Government:** [Aspects of Ferogan](../../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md)

## The Flame of Ferogan

Smoke first, they say. Then heat rolling down off the high shoulders of the [Kharsk Mountains](../../../../../world/kharsk-mountains.md) like something alive and hunting. That is how the frontier garrisons always start the story of [Varya](../../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/varya.md), and no two of them finish it the same way.

She graduated first in her class at [Atacella Academy](../../../../../world/kingdoms-regions/ferogan-empire/military-academies/atacella-infantry-academy.md) at seventeen, and the instructors there still argue over whether the feat says more about her talent or about a weak crop of students that year. Either way, the Academy sharpened her; It did not make her fearless. That happened later, in the mountains, when she and four other graduates climbed above the snow line chasing rumors of a wyrm denning in the high caves.

Only [Varya](../../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/varya.md) came back down.

Ask what happened up there and you will get five different answers depending on who is pouring the drinks. Some claim she starved the creature into submission over eleven days of siege. Others swear she walked straight into its den and simply refused to run, and that the dragon, confronted with a creature extruding no scent of fear at all, let her live out of something close to curiosity. [Varya](../../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/varya.md) rarely discusses it herself. Pressed, she touches the long scar running from her collarbone to her waist, and says the mountain kept the rest of the story.

She came down chilled to the bone, changed, wearing a scale the size of a shield wrapped to her spine. The soldiers who had once laughed at her academy manners started calling her the Flame before she had spoken a single word, and the name stuck ever since. She commands the whole of [Ferogan's](../../../../../world/kingdoms-regions/ferogan-empire.md) army now, holding the office of [Glory](../../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) as though it were simply the mountain's verdict made official, and not one soldier beneath her doubts she would walk back above that snow line tomorrow if the reason were good enough.
