---
id: c69623dd-550b-46e6-98c7-10a7ae9ad7d6
type: 'card'
entityType: 'Character'
aliases: ['Helias']
created: '2026-07-16T15:25:13.372718+00:00'
updated: '2026-07-21T17:07:35.484+00:00'
---

# Helias Vulgas

*Also known as Helias*

**Government:** [Aspects of Ferogan](../../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md)

## The Master of Wealth

Ask three different merchants how the Vulgas family has come to hold the office of [Wealth](../../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) on three separate occasions across two centuries, and you will receive three flattering answers, none of them complete. 

He grew up at card tables the way other children grow up on scripture or holy text. By eight he had beaten his own tutor at [Opeslya](../../../../../world/locations-landmarks/ferogan/opeslya.md) so many times running that the man quietly stopped offering him lessons, citing, in [Helias](../../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/helias-vulgas.md)’ retelling, if he kept playing with him that he’d be bankrupt by the end of the weekend. By twenty he was managing part of the family's shipping interests and had doubled their value twice over, once through a genuinely clever new route into the western ports, and once by convincing three competing merchants that each of them alone had thought of the idea first.

He almost never raises his voice, almost never shows a full hand at once, and rarely explains a decision before it has already become obvious, which has left more than one senator walking out of a private meeting with him convinced they had won an argument that [Helias](../../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan/helias-vulgas.md) had, in fact, settled three moves earlier.

He plays every table as he’s still that eight year old boy playing cards. With court politics, the slow grinding business of [Ferogan’s](../../../../../world/kingdoms-regions/ferogan-empire.md) treasury, and love, he lets the other player grow certain the table belongs to them before reminding them, graciously and without malice, exactly whose table it has always been.
