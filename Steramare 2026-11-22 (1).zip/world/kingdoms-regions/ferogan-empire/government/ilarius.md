---
id: 5d038455-e30f-41b3-858f-b473fb8aab87
type: 'card'
entityType: 'Character'
created: '2026-07-18T18:57:25.335594+00:00'
updated: '2026-07-21T17:08:39.766+00:00'
---

# Ilarius

**Kingdom:** [Ferogan Empire](../../../../world/kingdoms-regions/ferogan-empire.md)  
**Government:** [Aspects of Ferogan](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md)

## Overview
