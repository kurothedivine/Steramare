---
id: d40cfccb-5d80-40ac-bd4a-9acf81b58f7b
type: 'card'
entityType: 'City'
created: '2026-04-21T02:16:13.499415+00:00'
updated: '2026-07-16T19:37:38.733+00:00'
---

# Nochstadt
