---
id: eaef0ee5-4bf9-4ac0-8e11-63518bf9f3ba
type: 'card'
entityType: 'Character'
aliases: ['Leon']
created: '2026-04-24T21:55:03.628098+00:00'
updated: '2026-07-18T18:18:54.502+00:00'
---

# Leon Eisenwacht

*Also known as Leon*

**Noble House:** [House Eisenwacht](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md)

## Overview

[Leon](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht/leon-eisenwacht.md) serves as the commander-in-chief of [Nochstadt’s](../../../../../world/kingdoms-regions/nochstadt.md) army and city watch.
