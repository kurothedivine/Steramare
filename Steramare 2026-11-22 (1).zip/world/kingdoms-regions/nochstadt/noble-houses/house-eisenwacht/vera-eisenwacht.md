---
id: a5033329-0be7-4401-87dc-c06ffc796c9b
type: 'card'
entityType: 'Character'
aliases: ['Vera']
created: '2026-04-26T17:13:46.427847+00:00'
updated: '2026-07-18T18:19:12.463+00:00'
---

# Vera Eisenwacht

*Also known as Vera*

**Noble House:** [House Eisenwacht](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md)

## Nochstadt's Verdict

The city's common residents hold two opinions about [Vera](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht/vera-eisenwacht.md) [Eisenwacht](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) simultaneously and without apparent discomfort. 

She is frightening, yet is the perfect person when someone genuinely guilty needs to be brought to account.

The Upper Houses find her considerably more dangerous than [Leon](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht/leon-eisenwacht.md) in immediate practical terms, and considerably easier to manage in the long run. Unlike her brother, [Vera](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht/vera-eisenwacht.md) has no political ambitions, no interest in institutional reform, and no desire to be loved. She wants cases closed, and the rush that comes with bringing “scum” to justice. 

[Chernoglaz](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md), has a file on her that is three times the length of [Leon's](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht/leon-eisenwacht.md) filled with accounts of her sadistic nature and possible points of blackmail. They are keeping it for when they need it, which they consider a matter of when rather than if.

She has not yet found out about the file. When she does, the [Chernoglaz](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) have already modeled seventeen likely responses.

Twelve of them involve someone dying.
