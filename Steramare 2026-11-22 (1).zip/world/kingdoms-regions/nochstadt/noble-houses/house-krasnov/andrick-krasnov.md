---
id: e935dc2e-bea2-48e7-83fa-84a9cb074bdd
type: 'card'
entityType: 'Character'
aliases: ['Andrick']
created: '2026-05-29T19:16:40.039929+00:00'
updated: '2026-07-20T00:53:26.605+00:00'
---

# Andrick Krasnov

*Also known as Andrick*

**Noble House:** [House Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md)

## Overview

### **“The problem with **[Andrick](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/andrick-krasnov.md)** is that he loved life too much.”**

[Andrick Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/andrick-krasnov.md) was, by the majority of people, the most fun person in any room he entered. This was not always a compliment.

He inherited the house from [Ivan](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/ivan-krasnov.md) at twenty three, young enough to feel invincible and old enough to know better, which turned out to be the worst possible combination for a man with his appetites. Where [Ivan](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/ivan-krasnov.md) had been magnetic and deliberate, a man who understood that charm was a tool and wielded it like a rapier, [Andrick](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/andrick-krasnov.md) wielded it more like a flail. He loved everything loudly; the parties, the wine, the company,  and the reputation of being a [Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) in a city that treated the name like a promise of a good evening. He threw himself into all of it with the particular abandon of someone who has never once in his life felt the need to hold back.

The family's business did not necessarily suffer under him, exactly. The [Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) name carried enough momentum from [Ivan's](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/ivan-krasnov.md) meticulous blueprint that it could absorb a great deal of [Andrick's](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/andrick-krasnov.md) indulgences without losing ground. When needed to, [Andrick](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/andrick-krasnov.md) could play his role perfectly with his genuine talent at hospitality that the house depended on. He read people the way all [Krasnovs](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) read people, instinctively and accurately, and he was generous in the way that made others feel genuinely valued rather than managed. People loved him easily and he loved them back with equal ease, which is a rare quality and a genuinely useful one for a man in his position.

The problem was his overindulgence. It was never dramatic in the way that the other Houses would have noticed and acted on. It was gradual, the slow creep of a man who enjoyed too much discovering that more was always available to him, that no one in his immediate orbit was inclined to say no. The particular hunger the [Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) line carried became addictive, feeding not with satisfaction but with an appetite that quietly redrew its own boundaries over years.

[Lyda](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/lyda-krasnov.md), the youngest, watched her father the way perceptive children watch the adults around them, taking in more than anyone realized, pushing away the warmth and the laughter alongside the things that happened toward the end of long evenings, when the guests had thinned and her father's eyes had gone to somewhere else entirely.

[Ivan](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/ivan-krasnov.md) watched too, in his last years. He said nothing directly, because [Ivan](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/ivan-krasnov.md) never said anything directly when an indirect arrangement served better. He coldly named [Lyda](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/lyda-krasnov.md) his chosen successor and trusted that she would understand why when the time came.

The time came on a warm evening in the estate's east wing, during a private gathering that the official record describes as a dinner party. [Andrick](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/andrick-krasnov.md) had been celebrating something. He was always celebrating something. The details of what happened after the last formal guests departed have been removed from every account the family controls. To the public, [Andrick](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/andrick-krasnov.md) died of a heart attack, to others, he died from the aftermath of something more violent. 

He was forty one. He had five children, a city that adored him, and a particular hunger he had been battling with for a decade without ever once deciding to stop.

[Lyda](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/lyda-krasnov.md) has never discussed that night with anyone outside the family. She keeps a portrait of him in her study, something smaller than the large work hung up in the estate’s halls. It was of him painted when he was young, before the years of excess had begun their slow work on his face. In it he looks exactly like what he was before everything else.

Alive, passionate, and entirely unafraid of what came next.
