---
id: e98e4aca-593c-47f4-81b4-3a44e091953f
type: 'card'
entityType: 'Character'
aliases: ['Lyda']
created: '2026-04-24T22:19:26.740558+00:00'
updated: '2026-07-20T15:27:42.978+00:00'
---

# Lyda Krasnov

*Also known as Lyda*

**Noble House:** [House Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md)

## A Destined Legacy

[Lyda Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/lyda-krasnov.md) is beautiful.

Beautiful in the way that a fire is beautiful, or a storm is beautiful, or the dance of two lovers. Her existence serves as an constant performance. Yet the audience does not know they are currently participating in a show. It is simply what she is, and the effect it produces in rooms full of people who have seen everything is something closer to disorientation than admiration. 

As the granddaughter of [Ivan Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/ivan-krasnov.md), the man who carved [House Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) a seat among [Nochstadt's](../../../../../world/kingdoms-regions/nochstadt.md) Upper Houses through eastern wealth, extraordinary charm, and a gift for making powerful people feel they chose the decision he laid out, she grew up understanding that her name was not just a name. It was a standard. Just like every [Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) she has had a rigorous training on public appearance, social navigation, and the precise art of being the missing piece the room needs for an entertaining time. [Lyda](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/lyda-krasnov.md) received the same training as her siblings, sat through the same lessons on presence and performance and the careful management of perception, but was treated significantly different than her older brothers and sisters by [Ivan](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/ivan-krasnov.md). He had built his own legacy on instinct and audacity, on the willingness to be genuinely, unselfconsciously himself in rooms full of people performing careful versions of themselves, and he recognized this quality in his granddaughter.

After the passing of [Andrick](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/andrick-krasnov.md), it was a easy decision to appoint her as the next head of [Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md). Her four older siblings begrudgingly understood it very well., and has not spoken of it plainly since.

## The Night Everything Changed
