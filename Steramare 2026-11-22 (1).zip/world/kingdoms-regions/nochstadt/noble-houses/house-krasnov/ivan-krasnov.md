---
id: 15b08b98-76cd-41ae-b982-f3284c92eec7
type: 'card'
entityType: 'Character'
aliases: ['Ivan']
created: '2026-05-29T19:16:27.178364+00:00'
updated: '2026-07-18T18:19:18.699+00:00'
---

# Ivan Krasnov

*Also known as Ivan*

**Noble House:** [House Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md)

## Overview

 [Ivan](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/ivan-krasnov.md) arrived from the east with no formal introduction, no letters of standing, and no apparent concern about either. What he had was money, an accent that screamed authority, and the charm for those to . He did not petition for a seat among the Upper Houses. He simply made himself so embedded in the city's social and financial fabric over the span of two decades that refusing him one became more complicated than granting it.

What separated [Ivan](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/ivan-krasnov.md) from the many other wealthy, charming foreigners who had passed through [Nochstadt](../../../../../world/kingdoms-regions/nochstadt.md) and left no mark was that he was never performing. The warmth was real. The interest he took in people was genuine. He remembered names, remembered the specific details of conversations held years prior, and had a gift for making the most guarded people in the city feel, inexplicably, that they had known him their whole lives. The [Krasnov](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) bloodline's particular appetites lived in him too, but [Ivan](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/ivan-krasnov.md) wore them the way he wore everything else, with a discipline that looked effortless and had cost him considerably more than he ever let on.

He outlived his son [Andrick](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/andrick-krasnov.md) by several years, long enough to watch the thing he had built begin to tilt in directions he recognized but could not correct. He named [Lyda](../../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/lyda-krasnov.md) his successor, said nothing to anyone about why, and died quietly in the estate on a winter evening surrounded by people who loved him. [Nochstadt](../../../../../world/kingdoms-regions/nochstadt.md) mourned him the way cities mourn figures who have become part of the architecture. Not with grief exactly, but with the sudden awareness of an absence that had not existed the day before.
