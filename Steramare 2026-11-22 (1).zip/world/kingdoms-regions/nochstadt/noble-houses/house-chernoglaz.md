---
id: e7709f11-2f34-4428-8fd6-71d41eeca278
type: 'card'
entityType: 'Noble House'
aliases: ['Chernoglaz']
created: '2026-04-21T02:18:54.383234+00:00'
updated: '2026-05-29T19:40:55.27+00:00'
---

# House Chernoglaz

*Also known as Chernoglaz*

**City:** [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md)
