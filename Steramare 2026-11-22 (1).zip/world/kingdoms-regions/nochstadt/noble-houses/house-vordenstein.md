---
id: dcbc3ae1-86b4-46c8-8518-93828a216845
type: 'card'
entityType: 'Noble House'
aliases: ['Vordenstein']
created: '2026-04-21T02:19:34.161108+00:00'
updated: '2026-05-29T19:40:55.27+00:00'
---

# House Vordenstein

*Also known as Vordenstein*

**City:** [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md)
