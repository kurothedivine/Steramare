---
id: c2958169-7b05-4ddc-97b9-c6010a6bc6f1
type: 'card'
entityType: 'Noble House'
aliases: ['Krasnov']
created: '2026-04-21T02:15:39.334738+00:00'
updated: '2026-11-08T22:26:55.522+00:00'
---

# House Krasnov

*Also known as Krasnov*

**City:** [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md)

## Origins

### "The Red is not a warning. It is an invitation."

[House Krasnov](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) did not build [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md), nor fight against [the Lich King](../../../../world/lore/legendary/the-lich-king.md). What they did, and what they excel at, is making people *want* to be there.

They arrived late by the standards of the founding families, appearing in the city's records first as wealthy foreign merchants with vague eastern origins and extraordinary taste. Where they came from before [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md), no official document says. The family does not discuss it. They simply *were,* and then they were everywhere — at every important gathering, behind every celebrated venue, pouring wine for people who would later realize they couldn't remember the night clearly, yet desperately wanted to repeat it.

Within two generations of becoming guests of [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md), they joined the Upper Houses. They quickly became the city’s heartbeat.

## The Family

The [Krasnovs](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) are, without exception, beautiful. Not in the careful cultivated way of old money like the [Vordenstein](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-vordenstein.md), but beautiful the way a flame is beautiful. Warm, magnetic, impossible to look away from, and dangerous when you get too close.

They are also, by any reasonable measure, old. The current head of the family, [Lyda Krasnov](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov/lyda-krasnov.md), is said to be the founding patriarch's grandson. Those who have done the arithmetic soberly can see clear as day. The family ages slowly, gracefully, like fine things kept in perfect conditions.

No one in [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md) asks about this directly. It is considered very poor manners.

What they are is a subject the city treats the way it treats most uncomfortable truths — with willful elegance. The word ***vampire*** is not used in polite company. What is acknowledged, in hushed and thrilled tones, is that the [Krasnov](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) family has *particular appetites*, and that satisfying those appetites is, for the right kind of person, extraordinarily lucrative.

## The Crimson Trade

Somewhere between the city's licensed entertainment and its unlicensed underworld exists an arrangement with no official name. Visitors to [Krasnov](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) galas — the grandest events on [Nochstadt's](../../../../world/kingdoms-regions/nochstadt.md) social calendar — sometimes notice certain guests who circulate differently. They are beautiful, unhurried, and wear a small red ribbon somewhere on their person. They are treated as special guests, in which their special cloth gives them access to private areas most do not. 

They are, in the language that the city's more knowing residents use, *the vintage.*

The arrangement is voluntary, well-compensated, and more popular than it has any right to be. The rush of a [Krasnov's](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) attention is, by all accounts, intoxicating in its own right — and the coin paid afterward is genuinely life-changing. The waiting list for opportunity to become vintage is longer than the wait to get into their extravagant galas. There are people who make a career of it. Some stay their entire lives, while others suddenly go missing.

The other Houses treat this as the cost of doing business with [Krasnov](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md). When something goes wrong like the disappearance of special guests, the [Chernoglaz](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) quietly buries the record as if they didn’t exist. It has happened before, and will certainly happen again. The arrangement holds because [Krasnov's](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) value to the city is simply too vast to threaten over the occasional excess.

A [Krasnov](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) in full indulgence is not a pretty thing. Behind the charm and the candlelight is something older and considerably less refined — a hunger that, when given too much of what it wants, stops being selective. The other Houses call these episodes "the red hours." The [Krasnovs](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) themselves call them nothing. They do not discuss them. They simply ensure the flowers are fresh and the guest list is shorter the following week.
