---
id: 6932fa57-a3f0-4a21-b4f9-638fd1f96bbe
type: 'card'
entityType: 'Noble House'
aliases: ['Eisenwacht']
created: '2026-04-21T02:18:26.766944+00:00'
updated: '2026-11-08T22:26:55.695+00:00'
---

# House Eisenwacht

*Also known as Eisenwacht*

**City:** [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md)

## Origins

## *"We do not look away. We never have."*

[House Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) was not born in a counting house or a throne room. It was born on a **battlefield.**

When the war against [the Lich King](../../../../world/lore/legendary/the-lich-king.md) was at it’s peak and [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md) was still a fortress town bristling with soldiers, the [Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) were the order that held the line. Not a noble family then — a guild like the [Hagiser](../../../../world/factions/hagiser.md), whose members came from every background and rank but shared a single governing conviction: that order was not a luxury or a political tool. It was the only thing standing between civilization and anarchy.

After [the Shattering](../../../../world/lore/legendary/the-shattering.md), while others began the quiet scramble for position and profit, leaders of the [Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) made a different choice. They put down their campaign tents, took off their field armor, and stayed. They had defended this city when it was just a bastion against [the Lich King](../../../../world/lore/legendary/the-lich-king.md). They saw no reason to abandon it simply because it had lost its original purpose They incorporated as a noble house — formally, legally, with all the paperwork that [Vordenstein](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-vordenstein.md) required — and took on the role that no one else wanted and everyone needed: keeping [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md) honest.

Or at least, keeping it *functional.* They learned quickly that honesty and function were not always the same thing in this everchanging city.

## The Eisenwacht Family

The [Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) are not beautiful in the way that [Krasnov](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) is, nor ancient and imposing in the way that [Vordenstein](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-vordenstein.md) is . They are strong in a different register entirely — the kind of people who enter a room and immediately become the focal point that everyone else orbits around. Broad-shouldered, direct-eyed, with the particular quality of stillness that belongs to those who have trained themselves never to flinch.

They are also, by the standards of [Nochstadt's](../../../../world/kingdoms-regions/nochstadt.md) Upper Houses, startlingly honest. Not naive, especially in a city as cutthroat as [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md), but bluntly, almost aggressively straightforward. An [Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) will tell you what they think of your proposal, your politics, and your character without dressing it in pleasantry. Their strong military background taught them that consider social dissembling is a form of cowardice and to treat it accordingly.

This makes them the most trusted family in [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md) by a considerable margin, and the least comfortable to spend extended time with.

## Leon Eisenwacht — The Iron Warden

The images the city's artists most often return to when depicting the [Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) ideal are not the old generals or the founding commanders. They are [Leon Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht/leon-eisenwacht.md) — current captain of the house guard, heir apparent to the family seat, and the closest thing [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md) has to a figure that both the powerful and the common genuinely respect.

Although he is the youngest to hold his position. he is exactly the right person for it.

[Leon Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht/leon-eisenwacht.md) is the kind of soldier who kneels not out of submission but out of ritual — the sword before him not as a prop but as a promise. He came up through the family's training order the hard way, refusing the accelerated track that his name would have guaranteed, and emerged from it with the particular quality that the [Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) have always prized above rank or lineage: he does not bend. Not to [wealth](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md), not to charm, not to the quiet institutional pressure that the other Houses apply as naturally as breathing.

He has denied [Krasnov](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) entry to a restricted district twice. He has served [Vordenstein](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-vordenstein.md) with a formal audit notice on a property dispute. He has, on one memorable occasion, had a [Chernoglaz](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) courier detained for six hours on suspicion of carrying restricted materials — and been completely, infuriatingly correct.

The other Houses find him exhausting. The people of [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md), who hear these stories and feel something unfamiliar and warm in their chests, find him *reassuring.*

He carries a jeweled sword that belonged to the original [Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) founding commander — heavy, ornate, and kept in immaculate condition. Despite it’s ceremonial appearance, the jewels are not decorative. They are, as far as anyone has been able to determine, simply what the sword looked like when it was made, in a time when people built beautiful things to last. Some speculate it holds some sort of latent power, an [Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) secret that has been held tightly to the family. 

## The Chernoglaz Problem

Of all the tensions in [Nochstadt's](../../../../world/kingdoms-regions/nochstadt.md) Upper House politics, none is more publicly acknowledged and less publicly understood than the relationship between [House Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) and [House Chernoglaz](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md).

They dislike each other. This is not a secret. [Leon Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht/leon-eisenwacht.md) has called the [Chernoglaz's](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) methods "institutionalized deception dressed as statecraft" in an open [council](../../../../world/kingdoms-regions/republic-of-ruida/government/magus-council.md) session. The [Chernoglaz](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) response was to file the quote in their archive and say nothing, which somehow made the situation worse.

And yet — they work together constantly. More than any other pairing among the four Houses. More, in some months, thanEisenwacht works with [Vordenstein](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-vordenstein.md), who they actually respect.

The reason is simple and deeply uncomfortable for everyone involved: the [Eisenwacht](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) cannot enforce what they cannot find, and [Chernoglaz](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md)** always knows where everything is.**

[Leon](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht/leon-eisenwacht.md) needs the intelligence, and the [Chernoglaz](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) needs the enforcement arm — they watch everything but physically intervene in nothing, and there are moments when watching is not enough. This symbiotic relationship is efficient, effective, and conducted at all times with the energy of two people who would very much prefer to be working with anyone else else.

[Chernoglaz](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) finds Eisenwache's bluntness unsophisticated. Eisenwache finds [Chernoglaz's](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) opacity morally suspect. They are, between the two of them, responsible for most of what actually works in [Nochstadt's](../../../../world/kingdoms-regions/nochstadt.md) governance, and neither will admit this without visible reluctance.

 *"Verify everything independently before acting. Then act anyway, because they're usually right, which is the most irritating thing about them." *

-[Leon’s](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht/leon-eisenwacht.md) orders to his standing  lieutenant regarding  [Chernoglaz](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) information

## The Trust That Costs Something

What makes Eisenwache genuinely unusual among the Upper Houses is not their competence or their history. It is that they are the only house whose power derives, at least in part, from **being believed.**

[Krasnov](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-krasnov.md) is liked. [Vordenstein](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-vordenstein.md) is feared. [Chernoglaz](../../../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) is used. Eisenwache is *trusted* — and they have maintained that trust with extraordinary discipline over centuries, in a city that actively rewards the opposite. They do not take bribes. They do not play favorites. When they make arrests, the charges hold. When they issue permits, they are not for sale. When they say they do not know something, they genuinely do not know it.

This costs them. Regularly. Significantly. There is more money to be made in [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md) by looking the other way than by not looking. The Eisenwache have left a great deal of money on the table over the years and they know it and they do not especially care.

What they have instead is something no amount of gold purchases in this city: when an Eisenwache officer tells you something is safe, people believe them. When an Eisenwache seal appears on a contract, it holds. When Aldric Eisenwache stands in the [council](../../../../world/kingdoms-regions/republic-of-ruida/government/magus-council.md) chamber and says he will not permit something, every person in that room knows it is not a negotiating position.

In [Nochstadt](../../../../world/kingdoms-regions/nochstadt.md), that is rarer than gold. It is rarer, possibly, than anything.

*"The Eisenwache do not make threats. They make statements. The difference is that statements come true."*
