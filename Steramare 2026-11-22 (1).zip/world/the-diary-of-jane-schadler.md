---
id: c0b32c5d-94be-4e75-b964-076ae0de3083
type: 'story'
created: '2026-07-18T21:02:44.711979+00:00'
updated: '2026-11-09T07:31:51.708+00:00'
---

# The Diary of Jane Schädler

*A story — open it in vvd to view it.*

## Chapters

- [Before I Forget](../world/the-diary-of-jane-schadler/diary.md)
- [Glassy Sky](../world/the-diary-of-jane-schadler/glassy-sky.md)
- [Dark Will Fall](../world/the-diary-of-jane-schadler/dark-will-fall.md)
- [The Ghost of You](../world/the-diary-of-jane-schadler/the-ghost-of-you.md)
- [Trigger](../world/the-diary-of-jane-schadler/trigger.md)
- [Chapter 7](../world/the-diary-of-jane-schadler/chapter-7.md)
- [Chapter 8](../world/the-diary-of-jane-schadler/chapter-8.md)
