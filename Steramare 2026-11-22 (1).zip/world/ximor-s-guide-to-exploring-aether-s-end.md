---
id: 06152cfc-00ab-4c39-aebd-470289474e78
type: 'story'
created: '2026-07-22T20:44:02.561389+00:00'
updated: '2026-08-11T00:03:21.391+00:00'
---

# Ximor's Guide to Exploring Aether's End

*A story — open it in vvd to view it.*

shelley serif cormorant-garamond ink paper dark left flourish Chapter 1 image-below hardcover color #402000 cover e19301ba-65c2-4042-85d3-9186091b4c6f EB Garamond #000000 center #f5f1e6
