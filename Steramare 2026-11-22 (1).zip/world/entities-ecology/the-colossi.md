---
id: 58ec18cb-a7ac-4de9-94af-e5f862e417d9
type: 'card'
entityType: 'Ecology'
created: '2026-02-24T19:29:31.868733+00:00'
updated: '2026-04-24T19:33:36.707+00:00'
---

# The Colossi

**Ritual:** [Jökull's Proving](../../world/festivals-rituals/jokull-s-proving.md)

Nobody built [the Colossi](../../world/entities-ecology/the-colossi.md). Nobody summoned them. They arrived.

The oldest records in the [Scorchlands](../../world/kingdoms-regions/scorchlands.md). fragments of fired clay tablet found buried near the base of the largest Colossus, don't describe their creation. They describe an impact. Nine points of light falling from a sky that witnesses described as briefly, wrongly colored. Not the red of sunset or the black of night, but something in between that had no name and left people who saw it unable to sleep properly for weeks afterward. When the light cleared, [the Colossi](../../world/entities-ecology/the-colossi.md) were simply there. Already ancient-looking. Already still.

Between the high amounts of minerals and metals, the intense desert heat, and the constant threat of roaming Colossi, the living decided at some point to abandon its surface homes. This directly led to a series of underground cities and pathways like [Ember Run](../../world/locations-landmarks/the-scorchlands/ember-run.md).
