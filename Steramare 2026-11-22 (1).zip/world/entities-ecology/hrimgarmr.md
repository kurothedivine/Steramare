---
id: e377a138-fe8c-4529-a4fe-5867f1ce4864
type: 'card'
entityType: 'Ecology'
created: '2026-02-11T01:06:01.951107+00:00'
updated: '2026-04-05T13:57:05.762+00:00'
---

# Hrímgarmr

**Ritual:** [Jökull's Proving](../../world/festivals-rituals/jokull-s-proving.md)
