---
id: a2828e6a-c903-4b57-adcc-2697dc6b4165
type: 'timeline'
created: '2026-07-13T19:04:36.534288+00:00'
updated: '2026-08-11T00:03:21.391+00:00'
---

# Timeline

*A timeline — open it in vvd to view it.*

## Events

- Creation of Nochstadt — The Vordenstein, with the backing of local governments creates Nochstadt as a main base to fight against the Lich King.
- Rebellion of the Southern Islands
- Awakening of the Colossi
- The Scorchland Migration
- Aldric Brenton Invents Arcpowder
- House Eisenwacht joins Nochstadt
- House Sokolsky joins Nochstadt
- House Krasnov joins Nochstadt
- The Battle for The Realm
- Birth of the Hagiser
- Forming of the Fated Five
- Magic-less Uprising
- Five Banners Burning — Southern Islands: Pirate Federation who dislikes the Ferogan, recently seceded from them and the Republic of Ruida
Ferogan: Expansionist military power who likes to push their boundaries as much as they can get away with
Norodad: Isolationist north of the Ferogan who place a huge emphasis on tradition and religion.
Republic of Ruida: Magic republic undergoing technological evolution and political unrest
:  a rich empire south of the ferogan who follows ___, the king
- Ferogan's failed campaign at the Eastern Peaks
