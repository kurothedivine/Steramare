---
id: 9ca80353-1161-4503-b8fb-161188130c08
type: 'card'
entityType: 'Language'
created: '2026-02-10T06:23:00.477615+00:00'
updated: '2026-08-05T22:09:33.281+00:00'
---

# Norðkar
