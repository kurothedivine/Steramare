---
id: 7efad3e5-9099-4cc9-b98b-f693180592af
type: 'canvas-v2'
created: '2026-11-09T07:32:43.056909+00:00'
updated: '2026-11-09T07:32:45.839+00:00'
---

# New canvas

*A canvas v2 — open it in vvd to view it.*

canvas-v2
