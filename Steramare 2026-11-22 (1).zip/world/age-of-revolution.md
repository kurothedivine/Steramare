---
id: 26e53939-38f7-4060-93da-469d1633ca26
type: 'card'
entityType: 'Time Period'
created: '2026-07-17T18:24:11.652197+00:00'
updated: '2026-08-11T00:03:21.391+00:00'
---

# Age of Revolution
