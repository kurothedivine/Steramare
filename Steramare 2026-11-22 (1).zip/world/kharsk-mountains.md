---
id: e21de3bb-f7fd-49d5-a3d3-6c957d9422a9
type: 'card'
entityType: 'Location'
aliases: ['Kharsk']
created: '2026-07-21T16:52:48.290758+00:00'
updated: '2026-08-11T00:03:21.391+00:00'
---

# Kharsk Mountains

*Also known as Kharsk*
