---
id: 234db8f5-dc52-4975-9523-dd2b746ba97d
type: 'card'
entityType: 'Character'
created: '2026-09-11T18:55:10.909287+00:00'
updated: '2026-11-22T18:22:52.699+00:00'
---

# Xena

## Personality

As the third heir to the [Balik](../world/kingdoms-regions/jinrami/balik.md) \_\_\_, she has a strong personality. Xena is arrogant and highly confident in her abilities, reminiscent of Eris and Qiyana.

## Relationship With Matteo

She pushes around [Matteo](../world/matteo.md) and thinks the arranged marriage is stupid.

## Motives

As the third child, she may seek power to be respected by her older siblings, who are closer to becoming the next [Balik](../world/kingdoms-regions/jinrami/balik.md).
