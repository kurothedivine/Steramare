---
id: 40ab918f-1671-4e29-a92e-eb10f1b07c4a
type: 'card'
entityType: 'Character'
created: '2026-11-08T02:25:24.63295+00:00'
updated: '2026-11-08T21:07:03.761+00:00'
---

# The Burst

## Statblock

[The Burst](../world/the-burst/the-burst.md)

## Boss Theme

[New Spotify](../world/the-burst/new-spotify.md)
