---
id: 498a6093-637b-4b1c-9374-b26ffa758bc1
type: 'daggerheart-adversary'
created: '2026-11-08T03:41:11.267218+00:00'
updated: '2026-11-13T22:52:44.34+00:00'
---

# Spark Drone

*A daggerheart adversary — open it in vvd to view it.*

Spark Drone
