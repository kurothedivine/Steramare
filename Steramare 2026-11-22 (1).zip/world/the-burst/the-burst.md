---
id: e555776b-9c46-408b-abee-25512126754a
type: 'daggerheart-adversary'
created: '2026-11-08T01:42:45.75489+00:00'
updated: '2026-11-13T22:49:45.732+00:00'
---

# The Burst

*A daggerheart adversary — open it in vvd to view it.*

The Burst
