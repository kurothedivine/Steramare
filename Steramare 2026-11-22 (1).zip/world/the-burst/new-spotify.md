---
id: 24969b36-cb88-41a1-b04f-d3b7cb6bccd9
type: 'spotify-embed'
created: '2026-11-08T21:06:45.85834+00:00'
updated: '2026-11-08T21:06:52.528+00:00'
---

# New Spotify

*A spotify embed — open it in vvd to view it.*
