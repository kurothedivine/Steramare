---
id: 35916fcd-6fbd-434e-9a55-c5a4d1592774
type: 'card'
entityType: 'Book'
created: '2026-07-20T15:50:48.932115+00:00'
updated: '2026-07-22T20:38:33.254+00:00'
---

# The Diary of Jane Schädler

**Author:** [Jane Schädler](../../world/factions/cursed-children/jane-schadler.md)
