---
id: caaaa664-f05e-4a57-99cb-419ff46b5284
type: 'card'
entityType: 'Book'
created: '2026-07-16T15:38:29.91967+00:00'
updated: '2026-07-22T20:38:33.254+00:00'
---

# Ximor's Guide to Exploring Aether's End

**Author:** [Ximor](../../world/kingdoms-regions/aether-s-end/ximor.md)
