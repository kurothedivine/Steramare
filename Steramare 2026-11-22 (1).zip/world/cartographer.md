---
id: 034f5437-ccd6-449a-956c-f71f1399efb3
type: 'card'
entityType: 'Character'
created: '2026-07-20T17:03:58.672854+00:00'
updated: '2026-08-11T00:03:21.391+00:00'
---

# Cartographer
