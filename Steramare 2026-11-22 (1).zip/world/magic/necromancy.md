---
id: e70dbedf-7b39-4345-bcd4-83a8cf361a36
type: 'card'
entityType: 'Magic System'
created: '2026-02-10T09:39:17.62851+00:00'
updated: '2026-07-13T18:59:57.374+00:00'
---

# Necromancy
