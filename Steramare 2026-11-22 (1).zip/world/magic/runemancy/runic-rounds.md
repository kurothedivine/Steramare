---
id: 4a61f477-2746-4c50-a3d0-88093c4ed2b4
type: 'card'
entityType: 'Weapon'
created: '2026-04-05T21:24:48.728756+00:00'
updated: '2026-04-05T21:39:15.512+00:00'
---

# Runic Rounds

**Magic System:** [Runemancy](../../../world/magic/runemancy.md)
