---
id: 3541abfa-fff8-4eae-aba1-30672da920c3
type: 'card'
entityType: 'Weapon'
created: '2026-04-05T21:37:11.610924+00:00'
updated: '2026-04-05T22:07:45.442+00:00'
---

# Arcpowder

**Magic System:** [Runemancy](../../../world/magic/runemancy.md)  
**Weapon:** [Runic Rounds](../../../world/magic/runemancy/runic-rounds.md)
