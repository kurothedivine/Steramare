---
id: 5ab1395c-a2a3-4b72-921f-985ea9a9d857
type: 'card'
entityType: 'Magic System'
created: '2026-04-05T21:35:43.901881+00:00'
updated: '2026-07-13T18:59:57.374+00:00'
---

# Runemancy
