---
id: 142a7cb3-963d-48ae-b2ca-cfe9ecd692f6
type: 'card'
entityType: 'Magic System'
created: '2026-07-13T18:59:23.472132+00:00'
updated: '2026-07-13T18:59:57.374+00:00'
---

# Mana Radiation
