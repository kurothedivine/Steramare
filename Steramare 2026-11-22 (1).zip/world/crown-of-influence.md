---
id: 360f704e-811f-49b5-8f98-77ba3a839c22
type: 'card'
entityType: 'Item'
created: '2026-10-13T17:37:06.691498+00:00'
updated: '2026-10-13T17:37:09.414+00:00'
---

# Crown of Influence
