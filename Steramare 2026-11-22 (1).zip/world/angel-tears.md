---
id: d306192f-ca96-4a56-9b8e-ee3fc376d5e9
type: 'card'
entityType: 'Artifact'
created: '2026-08-05T21:43:32.894419+00:00'
updated: '2026-08-11T00:03:21.391+00:00'
---

# Angel Tears
