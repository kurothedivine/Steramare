---
id: 3e187c40-9e94-47ff-adad-cbb26688f6af
type: 'card'
entityType: 'Character'
created: '2026-09-11T18:55:42.235061+00:00'
updated: '2026-09-11T18:55:50.222+00:00'
---

# Matteo
