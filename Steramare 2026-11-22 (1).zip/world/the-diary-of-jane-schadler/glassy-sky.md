---
id: 1dccacd7-9ccb-4939-91d5-3720db7df7eb
type: 'chapter'
created: '2026-07-20T15:25:49.139619+00:00'
updated: '2026-11-11T19:24:23.974+00:00'
---

# Glassy Sky

My head hurts.

I can’t recall how many days have passed since I last picked up this pen. Time here does not move the way it used to. It pools and it drags and then all at once it slips through my fingers like water I forgot I was holding. I only know I am thinner than I was, and quieter, and that a version of me that existed before this place is beginning to feel like someone I read about once in a story.

They have started marking me.

Twice now, maybe three times, they have taken me to a round room beneath the east hall, the same room I saw that robed figure with wings. I say beneath because the stairs down feel longer each visit, though that could simply be my mind failing me the way everything here seems built to make it fail. They lay me on a table carved for a body my exact size, which tells me plainly enough that other bodies came before mine and were measured for it precisely.

Then a woman I have started calling the [Cartographer](../../world/cartographer.md), because I do not know her real name and because of the way she studies my skin like a map she is trying to finish, begins to draw.

Not with ink. With something sharper.

She uses a thin needle to traces lines into my arms and along my collarbone, symbols I do not recognize and could not repeat if I tried, each one opening like a small mouth in my skin before it closing again. I have stopped screaming during it. Not because it stopped hurting. Because I learned, the second time, that screaming only makes them pause and confer among themselves in low voices, as though my pain were a variable they had not accounted for and needed to write down.

The markings do not stay. I would call that strange, but with how my days have been going strange has become an afterthought. Once whatever they are testing for has come and gone, the marks fade from my skin like breath off a mirror, and by morning there is nothing left to prove any of it happened at all except the exhaustion, and the headache that sits behind my eyes for a full day after, and the sound.

I should write about the sound.

I have not told anyone about the sound.

It started small. A murmur under my thoughts, the kind of thing I assumed at first was only my own mind muttering to itself the way minds do in places like this. But it has gotten clearer. It has a shape now, almost a distinct voice, though it does not use words the way people do. It is more like a second attention living somewhere behind my own, watching what I watch, listening when I listen, occasionally leaning close enough that I catch the ghost of something like a syllable. I do not know if it is a symptom of what they are doing to me or the reason they are doing it at all. I do not know if it is mine.

Yesterday, during the marking, for the first time, it answered.

I’ll write more about that when I am ready.

---

They have started letting us out more.

An hour in the courtyard has become two. Meals are no longer taken alone in our cells but at long stone tables under open sky, or what I have started to suspect is not sky at all. I will come back to that.

I think all of this is meant to keep us sane. I have seen what happens to the ones left too long with only their own thoughts for company. The boy with the talon hands no longer answers to anything at all. The quiet ones stopped eating and had to be carried out on stretchers, not to freedom, I don't think, but somewhere else in this place I have not seen yet. Company, it turns out, is cheaper than losing an asset entirely.

Whatever the reason behind it, I am grateful, and I hate that I am grateful, and both of those things are true at once.

It was in the courtyard that I met [Esta](../../world/factions/cursed-children/esta.md).

She is an [elf](../../world/races/elf.md) with skin as bright as the sand at the beach, with a look about her like she is always halfway through deciding whether to run. She wears shackles during the day, unlike the rest of us, because a month before I arrived she broke an [Overseer Reznik’s](../../world/overseer-reznik.md)  nose with the flat of a serving tray and had to be dragged off by three guards. She told me this herself, at lunch, with the particular pride of someone recounting a fond memory.

She likes crows the way some people like a particular saint or god. She has names for the ones that nest above the courtyard. Six of them to be exact. She swears one of them, the largest, with a notch missing from its left wing, waits for her at the same corner of the wall each day. I asked her once whether she thought the birds knew what this place was. She said the birds were the only creatures here who could still choose to leave, and maybe that was answer enough.

We do not talk about why we are here. Not directly at least. It is an unspoken rule among the ones of us who still have our minds enough to make rules. But we talk around it, the way you might talk around a wound you are both trying not to touch, and in that talking around it I have started to gather pieces.

I do not think we are aboveground.

The sun in the courtyard is warm on my skin, and yet it never moves the way a sun should. It hangs in the same place at midday whether we are let out early or late. [Esta](../../world/factions/cursed-children/esta.md) noticed it before I did and would not stop staring at it that first afternoon until I asked her what was wrong. She said the light does not throw shadows quite right. The shadows fall some small fraction from where they ought to, as if someone painted the sky rather than let it happen on its own. I do not know who has that kind of power, or that kind of patience, but I know it is not something the world does by itself.

I still do not know who runs this place. Not truly. Not a name I could carry out of here and set in front of a magistrate. The [Chernoglaz](../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) insignia is stitched small on the guards' collars, easy to miss unless you are looking for it, and some [Ruida](../../world/kingdoms-regions/republic-of-ruida.md) mages come and go with their green regalia and papers [Reznik](../../world/overseer-reznik.md) signs without reading closely, the way a man signs something he knows is just a formality where his approval doesn’t *actually *matter. There is a third mark I have seen only once, on a crate being wheeled through the east hall, a symbol I do not recognize at all, foreign in a way that made even the guards lower their voices around it. I intend to learn what it means.
