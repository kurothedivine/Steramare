---
id: 226f247b-3332-415a-97da-a3e1c857e496
type: 'chapter'
created: '2026-07-20T17:22:57.693884+00:00'
updated: '2026-11-09T02:10:22.909+00:00'
---

# Trigger

[Reznik](../../world/overseer-reznik.md) stood at the edge of the ring with his hands folded behind his back, and for a long moment he just stared at us. No expression, not an inkling of emotion on his face, just staring. The more I interact with him, the more he confuses me. 

 Behind him, along the wall, the [Ruida](../../world/kingdoms-regions/republic-of-ruida.md) officials, or what I assume to be them,  waited in their strange dark coats, unmoved, unhurried, with the same dead fish expression [reznik](../../world/overseer-reznik.md) displayed.

Then he spoke.

He told us we had been treated with more patience than we understood. That every one of us had been marked, measured, and dosed with more care than our guests would ever guess, because coaxing a power out of a person gently is slower but far cleaner than forcing it out. He said that whatever we carried inside us, whatever shape it took, whatever it whispered to us in the dark hours of a cell, had a door somewhere. A trigger. Something inside of us that would open it wide enough to see through, once and for all. Fear was the easiest key, he said. Pain close behind it. And since neither had worked quickly enough on their own, in his considered opinion, he saw no reason not to try both together, dressed up as something almost resembling sport for the benefit of our guests.

He smiled when he said guests. I’m starting to despise that smile more than anything else about him.

He read four pairs of names off a slip of paper, mine held for last, and gave us the rules in the same breath he used to call them unnecessary. Fight until one of you cannot continue. Nothing more specific than that. Things are going to get ugly, very quickly. 

I found myself searching for the voice while [Reznik](../../world/overseer-reznik.md) spoke, half expecting it to whisper something back, some comment on the cruelty of it, a hint of some sorts on how to survive this inhumane act,  yet it stayed quiet. Listening, the way it always listens. Waiting, maybe, for a trigger of its own.

---

[Tomas](../../world/factions/cursed-children/tomas.md) fought first.

His opponent was a thin, older man I couldn’t recognize, someone who must have arrived while I was still learning the shape of my own cell. He didn’t look like a fighter. Not even a little. His hands shook before [Reznik](../../world/overseer-reznik.md) had finished speaking, and I found myself hoping, in the ugly, private way, that it would end quickly for both their sakes.

And indeed it did end quickly.

I sure [Tomas](../../world/factions/cursed-children/tomas.md) was not expecting for it to happen the way it did. For the first few moments he only circled, trying to find some sort of way they can both escape this terrible situation. Then the older man lunged at him with more desperation than skill, and [Tomas](../../world/factions/cursed-children/tomas.md) simply answered. His hands shaped into talons before I could even process what I was watching, faster than thought, faster than the gargling scream that came half a second behind them, and it ended almost as soon as it began. [Tomas](../../world/factions/cursed-children/tomas.md) stood over the man afterward, breathing hard, with a look on his face I recognized immediately, because I have worn it myself. Horror. Not at his opponent, but at himself.

They pulled him back before I could see anything worse. Whether the other man survived is more than I can say. Tonight, I have decided, is not the night I want to find out.

---

The third match was [Esta's](../../world/factions/cursed-children/esta.md).

I watched her walk into the ring with her chin up in a way that made my chest ache, because I have come to know that particular tilt of her head as the one she wears right before she does erratic, in my eyes at least. 

Her opponent struck first, and struck hard, and for one terrible breath I thought I understood exactly what I was about to lose.

Then her back split open.

Wings tore free from her shoulder blades, dark and enormous, unfurling like paper that has been folded for too long. The courtyard went utterly silent excluding the sound of her heavy breaths and the man across from her taking several steps backwards.

Those wings were belonged to her all along.

The recognition came slowly, and then all at once, like my brain didn’t want to accept the blatant truth that was in front of me. It was the shape of them. The particular shade of black of them, so deep they seemed to swallow the torchlight rather than reflect it. A cracked door surfaced behind my eyes. An older woman guarded on both sides. A robed attendant standing so calmly beside her that I had mistaken them, back then, for nothing more than part of the furniture of this place.

What the fuck is going on? Why was [Esta](../../world/factions/cursed-children/esta.md) wearing that robe? Is she really the prisoner she says she is?

By the time the memory had finished settling, [Esta](../../world/factions/cursed-children/esta.md) was already moving. She used the wings like a she’s had it her entire life, without hesitation, without the fumbling I might have expected from someone with a newly acquired limb. One beat sent her sideways, clear of her opponent's lunge. A second sent her barreling forwards, knocking him flat with an echo I felt in my spine 20 feet away. He sprung up swinging regardless, blood at his mouth, and for one awful moment she let him get close enough that I thought she meant to let the blow land. She didn't. She caught his wrist mid swing, twisted, and drove him down into the stones hard enough that the whole ring seemed to shudder with him.

Two guards carried him out, and [Esta](../../world/factions/cursed-children/esta.md) stood over the space where he had been with her wings still half spread, chest heaving, bearing a strong smirk like she’d forgotten she was that girl who told stories about her mother over lunch.

The officials along the wall were writing.

Something about that, more than the fight itself, turned my stomach.

She folded the wings back down slowly, wincing with every inch, as if they resented being put away. Watching her walk back toward me, still smirking, still catching her breath, I found myself circling a question with no good way into it. Was she the one standing behind that cracked door on my first days here? Is the robe that she was wearing some sort of uniform? Is [Esta](../../world/factions/cursed-children/esta.md) who she says she is? Are the stories about her mother and the [Eisenwacht](../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) is the whole of who she is, or only the piece she has judged safe to hand me? Are the stories even true?

I will ask her. Not tonight. My head is starting to spin, and I currently have bigger things to worry about. 

---

I am the last to fight.

They are bringing her forward now, the woman with the flinch, the one who still startles at every closing door.  I finally understand now what all of this leisure and all of these shared meals were truly for. Not kindness. Familiarity. They wanted us to know each other's names before they asked us to do this to one another.

I have not learned hers yet. I meant to. I kept meaning to, and there was always tomorrow, I thought. 

[Reznik’s](../../world/overseer-reznik.md) comments to the guests started to become quieter and quieter. I am looking at her instead, at her hands shaking the same way [Tomas's](../../world/factions/cursed-children/tomas.md) opponent's hands shook, and I am trying to decide, in the little time I have left to decide anything, what kind of person I am about to become.

And then, they called me forward.
