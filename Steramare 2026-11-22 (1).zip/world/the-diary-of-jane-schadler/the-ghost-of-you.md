---
id: b62e1d6a-ee6d-4998-9de8-599600ac4661
type: 'chapter'
created: '2026-07-20T17:51:12.087655+00:00'
updated: '2026-11-09T02:10:24.139+00:00'
---

# The Ghost of You

I have not been called back to the round room. Not since that night with the [Cartographer](../../world/cartographer.md), not since the runes and the shape in the bruised air and the word it left behind. Is the silence mercy or have they finished their purpose with me? Either way, I have started to flinch less at footsteps in the corridor, though the flinching never disappears entirely. 

I have used the quiet to look around me properly for the first time since I arrived, and to write down what I find, because I am beginning to suspect that memory is not something this place lets a person keep for free.

---

The boy with the talon hands has a name. [Tomas](../../world/factions/cursed-children/tomas.md). I learned it from one of the guards who is careless in the way tired men are careless, muttering things to each other over our heads as though we cannot hear, or as though it no longer matters whether we do. He was a fisherman's son from a coastal town I have never heard of, taken because his hands started changing the winter he turned fifteen. First the nails. Then the shape underneath them. He does not speak anymore. I do not know if that is because he cannot or because he has decided there is nothing left worth saying. I sat near him at the long table yesterday in silence. Mostly. I only wanted him to know someone had noticed his name and used it.

There are two new prisoners this week, brought in together, both still wearing the particular stillness I remember wearing myself. A woman who flinches at every closing door. A man who hasn’t eaten since he arrived, though the guards have started to threaten him about it the way they threatened me. I recognize the fashioning of what is happening to them, because it happened to me first, and there is nothing I can do to soften it. That recognition is its own kind of grief.

---

I have not told anyone about the voice.

It is clearer now than it was even a week ago. It no longer feels like a murmur beneath my thoughts. It feels, some hours, like a second person occupying the same skull, patient, watchful, entirely unbothered by anything that frightens the rest of me. I have started to wonder, in the hours when I cannot sleep, whether it is truly separate from me at all, or whether it is only the part of myself I was raised to keep quiet. The part that did not cry when the other children in [Nochstadt](../../world/kingdoms-regions/nochstadt.md) called me what they called me. The part that wanted, more than once, to give it back to them tenfold. I was a gentle child, or I tried very hard to be one, because gentleness was safer, because a poor miller's daughter with a strange mark her already had enough reasons for people to look at her twice. Perhaps the voice is what I would have become if I had never learned to be timid. 

Perhaps that is what they are trying to dig out of all of us here. Not a monster. Only the version of us that stopped apologizing for existing.

I think of my father sometimes, dusted in flour to his elbows, humming some tuneless thing while the mill wheel turned behind him, and I have to close my eyes until the memory stops feeling like a wound.

---

[Esta](../../world/factions/cursed-children/esta.md) and I have started sitting together at meals.

I did not plan for it to become a habit. It simply just happened, maybe because this is one of the few things I have control over. She talks more than I do, which suits me, because I have found I like listening to her more than I like the sound of my own voice these days. She told me, three days ago, that she used to be a guard herself, before all this, sworn into the [Eisenwacht](../../world/kingdoms-regions/nochstadt/noble-houses/house-eisenwacht.md) at seventeen because her mother wanted one child in a uniform and [Esta](../../world/factions/cursed-children/esta.md) was the only one who could be talked into it. She lasted two years. She said it the way someone describes a bad fever they are grateful to have survived. She was dismissed for striking a superior officer who “had it coming”, in her words and refused to explain further no matter how I asked. She only smiled at me in a way that told me the rest of that story was hers to keep for now.

I told her about the mill. About my father's hands covered in calluses and grain. About the sound the wheel made at dusk which I didn’t know I missed until I felt something in my chest loosen slightly.

She looked at me for a long moment after that. Longer than the story deserved. I looked back, and neither of us seemed in any hurry to be the one to look away first. I’m not sure how to describe that moment, only that my face was warm afterward for reasons that had nothing to do with the sun that isn’t a sun.

I am aware of how strange it is to feel anything like that here. I’m not going to look into it too closely. Some things survive better left alone.

---

Something has shifted these past two days, and not the good kind of shift.

[Reznik](../../world/overseer-reznik.md) has been everywhere. Ordering the guards to scrub the courtyard stones. Ordering new torches hung in the east hall. He carries a tightness in his shoulders that even [Esta](../../world/factions/cursed-children/esta.md), who despises him, admits she has never seen on him before, not even the day she broke his nose. The [Cartographer](../../world/cartographer.md) has not appeared at meals in two days. Whispers move faster than usual among the prisoners who still trust each other enough to whisper. Someone is coming. Someone [Reznik](../../world/overseer-reznik.md) answers to, which is a fact I did not know until this week, because I had assumed, foolishly, that a man so comfortable with cruelty must have been the source of it rather than merely its instrument.

I heard one guard mutter a word to another as they passed my cell this morning. Calibration. I could tell that he felt pity, but why?

They came for eight of us tonight.

Myself. [Esta](../../world/factions/cursed-children/esta.md), her shackles removed for the first time since I have known her, which frightened me more than the chains ever did. [Tomas](../../world/factions/cursed-children/tomas.md). The new woman who flinches at doors. Four others I only know by face, not name, though I intend to learn them if I am given the chance.

They walked us to the courtyard under torchlight. The stones had been scrubbed clean, and there was a ring drawn in something dark across the center of the ground, and along the wall stood people I had never seen before, dressed in a manner none of the guards dress, watching like we were livestock being auctioned off.

[Reznik](../../world/overseer-reznik.md) was smiling. I have never once seen [Reznik](../../world/overseer-reznik.md) smile.

What kind of sick fantasy would make ***him ***smile.

He said something about investment, and about return, and about how patience was a resource even the [Chernoglaz](../../world/kingdoms-regions/nochstadt/noble-houses/house-chernoglaz.md) could not spend forever.

Then he told us to choose partners.

I do not know what I am writing this for except that my hands needed something to do while I waited, and now there is no more time to wait.

They are calling numbers.
