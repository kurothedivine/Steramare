---
id: dcbe2f43-a1c0-4cb6-9bdd-56e20839f216
type: 'chapter'
created: '2026-07-20T16:23:46.570867+00:00'
updated: '2026-10-02T19:57:30.158+00:00'
---

# Dark Will Fall

I said I would write about yesterday. I am ready now, I think, or as ready as I will be.

They took me down to the round room again. The [Cartographer](../../world/cartographer.md) drew longer this time, more lines than before, up my arms and across my sternum and along the ridge of my spine, and the pain was different too. Sharper. With a pull to it, like something beneath my skin was being asked to come forward and had not yet agreed to.

I do not remember deciding to let it.

One moment I was on the table with my teeth locked shut against a scream I had promised myself I would not give them. The next the air above me had gone the color of a bruise, and something was standing where there had been nothing, tall and unfinished looking, made of a kind of dark that seemed to drink the torchlight rather than reflect it. I could not tell you what it looked like exactly. My eyes kept sliding off it like I was dodging glances at the sun. But I felt it look back at me. I felt it’s presence settle on me like a shoulder in a dark room.

The [Cartographer](../../world/cartographer.md) went very still. Someone in the corner of the room dropped a tray.

Then the runes on my skin went out like a snuffed candle, and the shape folded back into wherever it had come from, and I was left shaking on the table with the taste of copper in my mouth and no memory of screaming, though my throat was raw enough afterward to suggest that I had.

Nobody explained to me what happened when I lost consciousness. They only scribbled heavily in a book I was not allowed to see.

But I heard it again last night. Not the murmur this time. The voice, closer than before, whispering to me the way you would speak to someone you did not want to startle.

*“Soon.”*

What the fuck does that even mean?
