---
id: a5fea557-ef5f-46bc-acf6-af08ac0a6ee3
type: 'chapter'
created: '2026-07-18T21:02:44.741808+00:00'
updated: '2026-11-12T05:05:06.466+00:00'
---

# Diary

I’m not exactly sure what day it is. It may have been three sunrises, maybe four since I've arrived here. They don't let me see the sun long enough to keep track, only a slimmer of grey light through the slats before the guards pull the shutter closed again.

My name is [Jane Schädler](../../world/factions/cursed-children/jane-schadler.md)**. **

**JANE ELIZABETH SCH**Ä**DLER. **

I**’**m writing that down because someone here already tried to take it from me. 

On the first morning a woman in a brown trench coat asked my name, and when I gave it she wrote a number instead. 

**Subject 14****.**

 I will not be reduced to a number like cattle. I am [Jane Schädler](../../world/factions/cursed-children/jane-schadler.md), of [Nochstadt](../../world/kingdoms-regions/nochstadt.md), and I intend to keep saying so until my ink runs dry. 

This place doesn't have a name. There is no sign, no gate marked with a crest, nothing a traveler could point to and say "There! That is where they keep these secrets imprisoned!" I guess that's the point, I think. A place cannot be freed if no one knows it exists.

The building I'm kept in is made of old stone, colder than any winter I remember at home, and somewhere close there is a courtyard ringed in rusted iron where they walk us for exercise. Crows nest in the eaves above it. Dozens of them. They stalk us, patient and unbothered. I've started to envy the freedom the crows have.

I've seen three others so far.

A girl with dark green hair near my age who they take twice a day to a room down the east hall and who returns quieter each time, as though something is being poured out of her a little at a time.

A speechless boy, whose hands look more like talons than fingers, though he was, the green hair whispered, a fisherman's son about half a year ago. 

And a woman, older, kept apart from the rest of us, whom I only glimpsed once through a cracked door. Robed attendants stood on either side of her, and one of them had wings. I thought my eyes were playing tricks on me, but they were real. Wings, dark and folded, growing from the person's back as naturally as an arm grows from a shoulder. Their hands were red to the wrist, smothered in dried blood.

There is a name for what they are trying to build here, though no one has said it plainly to me yet. I have pieced together enough from the whispers passed cell to cell. They want to know what a person can hold before they break. How much power a body can carry, how far a soul can be stretched, how hard the flesh can be molded,  whether we can be shaped into something useful. A weapon, maybe. Or several. The envoys who visited on the second day did not look at us like people either. More like cattle waiting to be slaughtered. 

The most insane part is that the main gate is loosely guarded, with very little concern that we will try to cause a riot and attempt to escape. 

Why?

Some say its because the people they choose have nowhere left that would take us back. Others have families whose safety was explained to us very carefully, once, in a small quiet room. I’ve even heard rumors that some of the prisoners need the medicine they dole out twice daily to keep our own minds and bodies from turning against us. 

I'm still unsure what kind of prisoner I am.

I only know I was [Jane Schädler](../../world/factions/cursed-children/jane-schadler.md) before I came here, and I intend to stay as [Jane Schädler](../../world/factions/cursed-children/jane-schadler.md) when I leave, whatever the cost.
