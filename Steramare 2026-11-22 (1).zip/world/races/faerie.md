---
id: 4b7ba4e2-442e-41c5-81c8-6820c6b250f8
type: 'card'
entityType: 'Race'
created: '2026-08-07T02:02:52.551466+00:00'
updated: '2026-08-07T02:04:41.947+00:00'
---

# Faerie
