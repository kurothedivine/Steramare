---
id: 1ddf5b85-8186-423f-bb32-2862034f0153
type: 'card'
entityType: 'Race'
aliases: ['Northmen']
created: '2026-02-10T06:31:04.732812+00:00'
updated: '2026-08-07T02:04:11.486+00:00'
---

# Norðdade

*Also known as Northmen*

The [Norðdade](../../world/races/nor-dade.md) are a race of tribesman that speak [Norðkar](../../world/languages/nor-kar.md). Their affinity for the cold, traditional lifestyle, and hellish terrain has led them to live a life of isolationism, rarely interacting with the rest of the continent. 

Most [Norðdade](../../world/races/nor-dade.md) are usually referred through their lineage, such as “Thor, son of Zeus”.

The [Norðdade](../../world/races/nor-dade.md) participate in a traditional called the \_\_\_\_\_, which is a rite of passage for young warriors. At the end of the year, three chosen candidates ages 15-18 would travel into the Forest of \_\_\_\_\_, a place that is closely tied towards spiritual entities and magic. After performing a ritual called the \_\_\_\_\_, and a word of good luck, the Chieftain would leave the forest until the young warrior defeated the \_\_\_\_, or died trying. After defeating the monster, the warrior would be given a tattoo, join the [Jökullverd](../../world/factions/jokullverd.md),  and given a new name, symbolizing the recognition into manhood and rebirth. This new name often replaces their lineage or birth name, in which those would not be referred to their parents and lineage reference.  It often references a significant trait, characteristic, or life altering moment of that individual.
