---
id: a94b40ec-5031-4e4c-a06f-a3f042fa77ac
type: 'card'
entityType: 'Race'
created: '2026-08-07T01:57:18.582048+00:00'
updated: '2026-08-07T02:04:11.486+00:00'
---

# Faun
