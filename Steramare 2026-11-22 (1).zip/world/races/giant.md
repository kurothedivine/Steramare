---
id: 595f4732-92a5-469a-b4de-0d4abfb57601
type: 'card'
entityType: 'Race'
created: '2026-08-07T01:56:48.964177+00:00'
updated: '2026-08-07T02:04:11.486+00:00'
---

# Giant
