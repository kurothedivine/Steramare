---
id: 7fcc6542-2580-4ab2-a1ed-c024cd98e157
type: 'card'
entityType: 'Race'
created: '2026-08-07T02:00:22.575545+00:00'
updated: '2026-08-07T02:04:11.486+00:00'
---

# Halfling
