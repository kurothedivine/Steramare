---
id: 60f52e09-29a0-40bb-8040-003ba48ca326
type: 'card'
entityType: 'Race'
created: '2026-08-07T01:56:30.905709+00:00'
updated: '2026-08-07T02:04:11.486+00:00'
---

# Elf
