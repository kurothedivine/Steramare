---
id: 2e9cc7e7-bb8f-4305-8f6b-0939ea13442a
type: 'card'
entityType: 'Race'
created: '2026-08-07T02:03:02.531365+00:00'
updated: '2026-08-07T02:04:11.486+00:00'
---

# Orc
