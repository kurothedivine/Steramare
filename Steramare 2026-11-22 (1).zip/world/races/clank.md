---
id: caffc075-30e2-452a-84a9-8f9fc542bf38
type: 'card'
entityType: 'Race'
created: '2026-08-07T02:01:04.761033+00:00'
updated: '2026-08-07T02:04:11.486+00:00'
---

# Clank
