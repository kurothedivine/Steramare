---
id: fc5f7e52-62cd-4138-b643-c89659e6b573
type: 'card'
entityType: 'Race'
created: '2026-08-07T01:58:00.789885+00:00'
updated: '2026-08-07T02:04:11.486+00:00'
---

# Dwarf
