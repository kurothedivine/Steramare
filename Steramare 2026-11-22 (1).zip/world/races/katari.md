---
id: 303c0d8c-ab80-4116-8aee-fdd9b8b59dfb
type: 'card'
entityType: 'Race'
created: '2026-11-07T23:29:06.107243+00:00'
updated: '2026-11-07T23:29:16.854+00:00'
---

# Katari
