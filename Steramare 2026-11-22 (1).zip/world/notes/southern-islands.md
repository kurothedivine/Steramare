---
id: e412cbe8-ee72-4e71-9413-0ad52029718a
type: 'canvas-v2'
created: '2026-04-20T23:14:31.546166+00:00'
updated: '2026-10-08T17:35:54.803+00:00'
---

# Southern Islands

*A canvas v2 — open it in vvd to view it.*

Southern Islands Origin/Inspiration <p>-Bilgewater, Pirates of the Carribean, Leviathans, Wind Waker, Libertalia (Uncharted 4), <a target="_blank" rel="noopener" class="H23r4e" href="https://pirate.fandom.com/wiki/Republic_of_Pirates"><strong><u>Republic of Pirates</u></strong></a> in Nassau</p><p>-Previously colonized after the Shattering by established kingdoms, fought for independence, primarily run by pirate warlords (meteorcracy)</p><p>-was a inland united country in the past, but the shattering reduced their landmass by over 50%, causing the kingdom to implode on itself (thats when the ferogan attacked and took over)</p><p>-Each island has a "king", informal confederation against external influence</p><p>-Communist pirates? kind of like a robin hood type of vibe. could be a major ideological point due to ferogan's influence</p><p>- CONFEDERATION! states powers &gt; federal powers, they only unite for foreign affairs</p><p>-weapon tattoos!!!!!!</p><p>-pincho can be a game of the southern islands</p>
