---
id: d3e767a0-f95d-40f3-bede-73ca5da86959
type: 'canvas-v2'
created: '2026-04-20T23:02:13.858089+00:00'
updated: '2026-07-18T17:56:56.991+00:00'
---

# Aether's End

*A canvas v2 — open it in vvd to view it.*

Aether's End Ideas <p>-Elite archer group (simular to the yuyan in atla)</p><p>-sablewood being a part of aether's end</p> Origin/Influences <p>-fey,legend of zelda, monster hunter, living ecosystem, studio ghibli, amazonian rainforest</p><p>-death of a dryad or goddess? (maybe their resting spot)</p><p>-what caused their death? what is old age? rebirth cycle? conflict?</p><p>-write entries from the perspective of someone exploring aether's end (Ximor's guide to all of aether's end)</p><p>-if going mana crystal route regarding ruida, it makes sense to put aether's end south of ruida (mana crystals might have leaked downstream, evolving the ecosystem. justifies more hybrid entities like fungal people)</p><p>-read more into the "beast feast" daggerheart campaign frame</p><p>-small villages set up around aether's with different type of societies, no form of overarching government (bunch of different tribes living in one large ecosystem)</p><p>-</p>
