---
id: cf6ecadd-341e-483c-bc40-02de7d28dd1e
type: 'canvas-v2'
created: '2026-04-20T23:16:09.29441+00:00'
updated: '2026-11-08T22:17:19.754+00:00'
---

# Norodade

*A canvas v2 — open it in vvd to view it.*

Norodade Origin/Inspiration <p>Witcher, Death Watch, American Indian, Vikings, Dark Souls, Slavic Fantasy</p><p>-Language influence: Old Norse and Mando'a</p><p>-”We teach our children fairy tales of dragons and monsters not to scare them, but to tell them that they can be beaten.”</p><p>-Jokullverd is an elite group that prides themselves on their strength. Current duties</p><p>*Serve as a small, elite standing army against invasions from Ruida and Ferogan</p><p>*Protects villages from monstrosities, spirits, and more</p><p>*Conducts rituals to keep the gods tame</p><p>*In extreme cases, conduct covert operations outside of Norodad lands<br></p><p></p>
