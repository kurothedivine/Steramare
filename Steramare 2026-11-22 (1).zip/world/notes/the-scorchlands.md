---
id: b8ab2705-02fb-4883-bf9f-ceb673ecd3c9
type: 'canvas-v2'
created: '2026-04-07T04:57:36.828945+00:00'
updated: '2026-11-08T21:53:59.379+00:00'
---

# The Scorchlands

*A canvas v2 — open it in vvd to view it.*

The Scorchlands Origins/Influence <p>-shadow of the colossus, wild west (weird west), the gunslinger (stephen king)</p><p>-why would people willingly go to the Scorchlands?</p><p>-potential fortune, escapism from past lives (criminals, family life, reputation) </p><p>-introduction of firearms may have egged on/led non-magical citizens of ruida to leave and explore the southern frontier</p><p>-privatized law enforcement (Pinkerton Agency) and publicized incentives (bounties)</p><p>-"keeping the peace was seen more as a private endeavor than a public one"</p><p>-john brown</p><p>-what causes the colossi to appear?</p>
