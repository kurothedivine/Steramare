---
id: 666e1490-24cd-4173-88c0-fafea7629a9b
type: 'canvas-v2'
created: '2026-04-21T00:12:35.646283+00:00'
updated: '2026-10-15T18:18:49.673+00:00'
---

# Hagiser

*A canvas v2 — open it in vvd to view it.*

Hagiser Origin/Inspo <p>Greece, Holy Warriors, Jedi, Aasimar</p><p>Language Inspo: Greek and Italian?</p><p>Are some of them natural born aasimar? Do they inherit aasimar traits later down their service?</p><p>where do they reside in the world? where is their current base of operations?</p><p>-some sort of brand on their body that establishes their holy magic, also lets others know they are hagiser (gear symbol)</p>
