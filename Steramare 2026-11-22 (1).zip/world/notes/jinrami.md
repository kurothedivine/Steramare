---
id: f243e804-699f-4358-8d8c-9fda8f32a264
type: 'canvas-v2'
created: '2026-07-16T16:23:14.325926+00:00'
updated: '2026-08-05T21:41:36.415+00:00'
---

# Jinrami

*A canvas v2 — open it in vvd to view it.*

Jinrami Jinrami <p>-Inspirations: prince of persia, ming dynasty, southern africa, wakanda, shurima,</p><p>-Language Influence: Chinese (Jin - Gold) , Egyptian Arabic (ramil - Sand)</p><p>-climate: tropical, close desert in some areas (more south, closer to the scorchlands)</p><p>-wealthy kingdom, monarchy, rivals with the ferogan empire (close borders, their expansionist ideology clashes on their way of life)</p><p>-natural border of the mountain range has kept the ferogan from launching an invasion, two major chokepoints between the ____ river and the ____ pass</p><p>-how did this kingdom gain their wealth? (textiles, perfumes, and jewerly)</p><p>-royal bloodline</p><p>-physical appearance is VERY important in jinrami society</p><p>-why do jinrami ideals clash with ferogan ideals?</p><p>-how does the goddess mattai link with jinrami? does she relate to the scorchlands at all?</p><p></p><p></p><p></p>
