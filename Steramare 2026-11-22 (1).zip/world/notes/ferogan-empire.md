---
id: f2031344-e8fc-4bc6-82e2-9eedc41be8af
type: 'canvas-v2'
created: '2026-04-20T23:41:52.993943+00:00'
updated: '2026-07-22T18:55:39.072+00:00'
---

# Ferogan Empire

*A canvas v2 — open it in vvd to view it.*

Ferogan Empire Inspiration/Origin <p>-root language: Latin and Russian</p><p>-influences: might makes right, noxus, red scare, roman empire</p><p>-trying to get their foot into the door with Nochstadt indirectly (marriage into families, spy network, good public relations)</p><p>-what causes their expansionist ideology? (maybe 2 main waves of expansionist ideology (before and after the War Against the Living)</p><p>-empires to research: mongolian, persian, british</p><p>-conquered/controlled the chaos before and during the shattering, uses that as the casus belli for expanding their empire ("you guys would do a lot better if you let us control your resources")</p><p>-ferogan treats war like a business, so much so that they seperate their military forces into 5 academies that have training specialization (infantry, calvary, artillery and siege, support logistics, and naval.</p><p>-three main rulers who were elected, but ruled for life usually ruled for life (many times, they were killed, exiled, impeached, or fled because of the people, making this "rule for life" more of a concept rather than a fact)</p><p>-Each Ruler (called the Aspects of Ferogan) controlled one aspect of ferogonian life; Glory (Controls the army) Conflict (Controlled the Senate) and Wealth (self explanatory)</p><p>Leaders at 160 AS:</p><p>-Amata (Senate): described as so beloved of the people, that she beheaded ____, the previous leader of the senate in broad daylight and was still not charged with regicide, the people cheered and she gained favor immediately</p><p>Varya(Army): also known as "The Flame of Ferogan" she was a top graduate at Atacella Academy, and is one of the handful of people from Ferogan to survive taming a wild dragon from the mountains of ___.</p><p>Helias(Finances): comes from a long line of previous Ferogan rulers, he is often praised for his wits and cunning. An avid player of card and mind games.</p><p></p><p></p><p></p>
