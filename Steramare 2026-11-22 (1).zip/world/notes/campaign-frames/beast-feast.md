---
id: 312c2204-d190-443c-a668-3a573cac73ad
type: 'canvas-v2'
created: '2026-08-09T20:11:51.09322+00:00'
updated: '2026-08-10T23:29:48.91+00:00'
---

# Beast Feast

*A canvas v2 — open it in vvd to view it.*

Beast Feast Beast Feast! <p>-Delicious in Dungeon, Monster Hunter World, One Piece, Konosuba</p><p>-monster defense system fails, </p><p>-</p>
