---
id: ca9fa3b2-ac9e-4489-a965-756de64c00fe
type: 'canvas-v2'
created: '2026-08-07T20:42:23.530071+00:00'
updated: '2026-08-09T20:12:03.118+00:00'
---

# Witherwild

*A canvas v2 — open it in vvd to view it.*

Witherwild Witherwild <p>-Influences: Legend of Zelda, Princess Mononoke, The Dark Crystal, Nausicaä of the Valley of the Wind, Avatar (Blue People)</p><p>-Respect nature and it's ways, or the consequences can be immense</p><p>-smaller divinities or gods who influence those with ill intentions to Aether(aether was a goddess of nature who's dying breath came to create the vast forest, most of the inhabitants refer to the place as "aether's new body")</p><p>-Serpent's sickness, cough leads to scaly skin, which leads to the solidification and hardening of the organs, petrifying the sick person. outbreak in Ruida</p><p>-some magic works on the petrified users, but only temporarily. the body still has the sickness even if someone can remove the petrification</p><p>-Archmage in Ruida figures out about rare plant in Aether's End called the Crimson Lady that can cure the sickness, thus leads to the invasion of Aether.</p><p>-Reaping Eye, Sowing Eye (Fall &amp; Spring), reaping eye was stolen by Ruida, so Aether is stuck in an everlasting spring </p> Communities  <p></p>
