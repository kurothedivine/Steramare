---
id: a52863cc-8b5e-415e-938e-af53d8fd3a86
type: 'card'
entityType: 'Event'
created: '2026-07-14T23:17:37.780685+00:00'
updated: '2026-10-13T17:33:47.356+00:00'
---

# Five Banners Burning

## Overview

Five years into a cease-fire that ended a long war, the realm of [Steramare](../../../../world/lore/legendary/origins-of-steramare.md) is facing the threat that the flames of war will be reignited. Five major nations intertwine in brewing tensions and complex rivalries, seeking to exploit the magical, social, and political changes of what historians call the [Age of Revolution](../../../../world/age-of-revolution.md).

- Tone & Feel: Adventerous, Dramatic, Intimate, Politcal, Serious

- Themes: Divided Loyalties, The Nature of Power, The Price of Ambition, Tradition vs. Innovation

- Inspirations: Avatar: the Last Airbender, Court of Blades, Game of Thrones, Dragon Age: Inquisition, A Song of Ice & Fire

## The Five Kingdoms

[Southern Islands](../../../../world/kingdoms-regions/southern-islands.md): is a pirate federation who profits through trade and raiding merchant ships. Recently seceded from the [Ferogan Empire](../../../../world/kingdoms-regions/ferogan-empire.md), they seek to increase their [wealth](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md), they seek to increase their [wealth](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) through naval superiority.

[Ferogan Empire](../../../../world/kingdoms-regions/ferogan-empire.md): is an expansionist military power who likes to push their boundaries as much as they can get away with. They seek to prove their strength through military presence, and welcome more territories to their glorious empire.

[Norðdad](../../../../world/kingdoms-regions/nor-dad.md): is an isolationist kingdom north of the [Ferogan](../../../../world/kingdoms-regions/ferogan-empire.md) who place a huge emphasis on tradition and religion. They seek to keep the gods pleased, protect the arcana, and defend their lands against foreign control.

[Republic of Ruida](../../../../world/kingdoms-regions/republic-of-ruida.md): is an oligarchic republic centered around wealthy mages, which is undergoing technological evolution and political unrest due to the inventions of [Aldric Breton](../../../../world/lore/continental/aldric-breton.md). They seek to increase their monopoly on magic and suppress the ideas of revolution within their borders.

[Jinrami](../../../../world/kingdoms-regions/jinrami.md): is a rich empire south of the [Ferogan](../../../../world/kingdoms-regions/ferogan-empire.md) who follows the [Balik](../../../../world/kingdoms-regions/jinrami/balik.md), the king of [Jinrami](../../../../world/kingdoms-regions/jinrami.md). They are long standing rivals with the [Ferogan Empire](../../../../world/kingdoms-regions/ferogan-empire.md), who have entertained many [conflicts](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md), who have entertained many [conflicts](../../../../world/kingdoms-regions/ferogan-empire/government/aspects-of-ferogan.md) with them in the past.
