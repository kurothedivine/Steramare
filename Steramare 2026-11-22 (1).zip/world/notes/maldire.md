---
id: ca9efe75-7319-4003-a942-cded3e41991c
type: 'canvas-v2'
created: '2026-04-20T23:15:09.288726+00:00'
updated: '2026-10-03T07:42:47.152+00:00'
---

# Maldire

*A canvas v2 — open it in vvd to view it.*

Maldire Origin/Influence <p>-necromancy, dark souls, shadow isles,</p><p>-salem witch trials(called the Zaali Trials?) the vacuum left after the lich king's death may have created a period of hysteria</p><p></p><p>-the offical return of the zaali sparks when The City of ____ suffers a massive loss of 86 people due to a necromancy terror attack, the first of its kind 18 years after the death of the Lich King (ie the Shattering)</p><p>-small signs leading up to the incident above, disfigured corpses found in smaller villages, sightings of zombies here and there, small incidents that higher ups different regions ignored</p><p>-the zaali still exists but arent as blatant as they once were (kind of like a terrorist organization)</p><p></p> The Zaali Trials Corvina Grey <ul><li><p>Ruida noblewoman who abandoned her house to join the zaali</p></li><li><p>She studied a lot of forbidden and vaulted texts/books on necromancy and the Lich King and grew an unhealthy obsession for him</p></li><li><p>yandere baddie( named the corpsemother?) leading the zaali trying to revive the lich king</p></li><li><p>sparks the return of the zaali, has never met the lich king but has developed a unhealthy love for him and his ideology. claims to be his wife waiting for him to return</p></li><li><p>quickly rose through the ranks of the zaali, now one of the heads</p></li><li><p>how does she receive the name corpsemother? is it because of her love for each corpse she raises from the dead?</p></li></ul><p></p> Corvina Grey
