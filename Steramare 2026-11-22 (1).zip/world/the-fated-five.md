---
id: bb78e140-3e6b-49cf-8a93-0b00150b9065
type: 'story'
created: '2026-07-21T17:03:45.060338+00:00'
updated: '2026-08-11T00:03:21.391+00:00'
---

# The Fated Five

*A story — open it in vvd to view it.*

shelley serif cormorant-garamond ink paper dark left flourish Chapter 1 image-below hardcover color #402000 EB Garamond #f5f1e6 center
