---
id: 149e3585-2e39-4534-be58-ddb5ffd814aa
type: 'card'
entityType: 'Noble House'
created: '2026-07-22T19:49:33.753368+00:00'
updated: '2026-08-11T00:03:21.391+00:00'
---

# House Jindara
