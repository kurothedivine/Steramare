# Steramare — exported from vvd

2026-11-22 · 183 documents · 0 media files

## What's in here

- **`world/`** — everything you wrote, as Markdown. Open it in any editor
  (Obsidian, iA Writer, VS Code) or just read it here. The folders match
  your sidebar, and documents link to each other. A card filed under
  another card sits in a folder named after that card, right beside it.
- Media was not included in this export — choose *Complete with media* to get your files.
- **`Steramare.vvd`** — your world's data, in vvd's own format.
  It holds the parts Markdown can't carry: maps, canvases, timelines,
  relationships, types and settings. Keep it if you ever want this world
  back — it's the file vvd reads.

Nothing here needs vvd to open except the last one. Your writing is yours,
in a format that will outlive us.